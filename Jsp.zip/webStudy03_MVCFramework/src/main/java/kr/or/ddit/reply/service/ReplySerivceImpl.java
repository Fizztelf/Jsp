package kr.or.ddit.reply.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.reply.dao.IReplyDAO;
import kr.or.ddit.reply.dao.ReplyDAOImpl;
import kr.or.ddit.utils.SecurityUtils;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ReplyVO;

public class ReplySerivceImpl implements IReplyService {

	private ReplySerivceImpl() { }
	private static ReplySerivceImpl self;
	public static ReplySerivceImpl getInstance() {
		if(self==null) self = new ReplySerivceImpl();
		return self;
	}
	private IReplyDAO dao = ReplyDAOImpl.getInstance();
	private SqlSessionFactory sqlSessionFactory = CustomSqlSessionFactoryBuilder.getSqlSessionFactory(); 
	
	private void encodedPassword(ReplyVO reply) {
		String encoded = SecurityUtils.encryptSha512(reply.getRep_pass());
		reply.setRep_pass(encoded);
	}
	
	@Override
	public ServiceResult createReply(ReplyVO reply) {
		encodedPassword(reply);
		int rowcnt = dao.insertReply(reply);
		ServiceResult result = ServiceResult.FAILED;
		if(rowcnt > 0) {
			result = ServiceResult.OK;
		}
		return result;
	}

	@Override
	public int retrieveReplyCount(PagingVO<ReplyVO> paging) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ReplyVO> retrieveReplyList(PagingVO<ReplyVO> paging) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReplyVO retrieveReply(int rep_no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult modifyReply(ReplyVO reply) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult removeReply(ReplyVO reply) {
		// TODO Auto-generated method stub
		return null;
	}

}
