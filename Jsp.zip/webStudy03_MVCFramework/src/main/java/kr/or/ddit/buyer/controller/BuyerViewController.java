package kr.or.ddit.buyer.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.buyer.service.BuyerServiceImpl;
import kr.or.ddit.buyer.service.IBuyerService;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.utils.JsonResponseUtils;
import kr.or.ddit.vo.BuyerVO;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ProdVO;

@Controller
public class BuyerViewController {
	private IBuyerService service = BuyerServiceImpl.getInstance();
	
	@RequestMapping("/buyer/buyerList.do")
	public String buyerList(@RequestParam(value="page", required=false, defaultValue="1") int currentPage,
			@ModelAttribute("searchDetail") BuyerVO searchDetail, HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException	 {
			
		PagingVO<BuyerVO> pagingVO = new PagingVO<>(7,3);
		pagingVO.setSearchDetail(searchDetail);
		
		int totalRecord = service.retrieveBuyerCount(pagingVO);
		pagingVO.setTotalRecord(totalRecord);
		pagingVO.setCurrentPage(currentPage);
		
		List<BuyerVO> buyerList = service.retrieveBuyerList(pagingVO);
		pagingVO.setDataList(buyerList);
		
		req.setAttribute("pagingVO", pagingVO);
		
		String accept = req.getHeader("Accept");
		if(StringUtils.containsIgnoreCase(accept, "json")) {
			JsonResponseUtils.toJsonResponse(req, resp);
			return null;
		}else {
			return "buyer/buyerList";
		}
	}
}
