package kr.or.ddit.member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.UserNotFoundException;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.mvc.annotation.RequestMethod;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;

@Controller
public class IdCheckController{
	private IMemberService service = MemberServiceImpl.getInstance();
	
	@RequestMapping("/member/idCheck.do")
	public String doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String inputId = req.getParameter("mem_id");
		if(StringUtils.isBlank(inputId)) {
			resp.sendError(400);
			return null;
		}
		boolean canUse = false;
		try {
			service.retrieveMember(inputId);
		}catch (UserNotFoundException e) {
			canUse = true;
		}
		resp.setContentType("text/plain");
		try(
			PrintWriter out = resp.getWriter();	
		){
			out.println(canUse);
		}
		return null;
	}
	@RequestMapping(value = "/member/idCheck.do", method=RequestMethod.POST)
	public String doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String inputId = req.getParameter("inputId");
		if(StringUtils.isBlank(inputId)) {
			resp.sendError(400);
			return null;
		}
		boolean canUse = false;
		try {
			service.retrieveMember(inputId);
		}catch (UserNotFoundException e) {
			canUse = true;
		}
		resp.setContentType("text/plain");
		try(
				PrintWriter out = resp.getWriter();	
				){
			out.println(canUse?ServiceResult.OK.name():ServiceResult.FAILED.name());
		}
		return null;
	}
}











