package kr.or.ddit.mvc.annotation;

public enum RequestMethod {
	GET, POST, PUT, DELETE, HEAD, OPTION, TRACE
}
