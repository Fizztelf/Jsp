package kr.or.ddit.mvc.annotation.resolvers;

import java.lang.reflect.Parameter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletSpecArgumentResolver implements IHandlerMethodArgumentResolver {

	@Override
	public boolean isSupported(Parameter parameter) {
		return parameter.getType().equals(HttpServletRequest.class) ||
			   parameter.getType().equals(HttpServletResponse.class) ||
			   parameter.getType().equals(HttpSession.class);
		
	}

	@Override
	public Object argumentResolve(Parameter parameter, HttpServletRequest req, HttpServletResponse resp) throws ServletException {
		Class<?> prarmeterType = parameter.getType();
		Object value = null;
		if(HttpServletRequest.class.equals(prarmeterType)) { // 현재 파라미터가 리퀘스트 필요
			value = req;
		} else if(HttpServletResponse.class.equals(prarmeterType)) {
			value= resp;
		} else {
			value = req.getSession();
		}
		return value;
	}

}
