package kr.or.ddit.vo;

import java.io.Serializable;

public class MenuVO implements Serializable {
	
	
	
	public MenuVO() {
		super();
	}
	
	private MenuVO(String menuText, String menuPath, String menuURI, String menuName) {
		super();
		this.menuText = menuText;
		this.menuPath = menuPath;
		this.menuURI = menuURI;
		this.menuName = menuName;
	}
	
	private String menuText;
	private String menuPath; // jsp path
	private String menuURI;  // model2 servlet mapping URI
	private String menuName;
	
	public String getMenuText() {
		return menuText;
	}
	public void setMenuText(String menuText) {
		this.menuText = menuText;
	}
	public String getMenuPath() {
		return menuPath;
	}
	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuURI() {
		return menuURI;
	}

	public void setMenuURI(String menuURI) {
		this.menuURI = menuURI;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuPath == null) ? 0 : menuPath.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MenuVO other = (MenuVO) obj;
		if (menuPath == null) {
			if (other.menuPath != null)
				return false;
		} else if (!menuPath.equals(other.menuPath))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "MenuVO [menuText=" + menuText + ", menuPath=" + menuPath + ", menuName=" + menuName + "]";
	}
	
	public static MemuVOBuilder getBuilder(){
		return new MemuVOBuilder();
	}
	
	public static class MemuVOBuilder{
		private String menuText;
		private String menuPath;
		private String menuURI;
		private String menuName;
		
		public MemuVOBuilder menuText(String menuText){
			this.menuText = menuText;
			return this;
		}
		public MemuVOBuilder menuPath(String menuPath){
			this.menuPath = menuPath;
			return this;
		}
		public MemuVOBuilder menuURI(String menuURI){
			this.menuURI = menuURI;
			return this;
		}
		public MemuVOBuilder menuName(String menuName){
			this.menuName = menuName;
			return this;
		}
		public MenuVO build() {
			return new MenuVO(menuText, menuPath, menuURI, menuName);
		}
	}
	
	
	
	
}
