package kr.or.ddit.vo;

import java.io.Serializable;
import java.util.Set;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import kr.or.ddit.validate.groups.UpdateGroup;
import kr.or.ddit.validate.rule.TelNumber;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of = "buyer_id")
public class BuyerVO implements Serializable {
	@NotBlank(groups = UpdateGroup.class)
	@Size(max = 10)
	private String buyer_id;
	@NotBlank
	@Size(max = 40)
	private String buyer_name;
	@NotBlank
	@Size(max = 4)
	private String buyer_lgu;
	@NotBlank
	@Size(max = 6)
	private String buyer_bank;
	@NotBlank
	private String buyer_bankno;
	@NotBlank
	@Size(max = 6)
	private String buyer_bankname;
	@NotBlank
	private String buyer_zip;
	@NotBlank
	private String buyer_add1;
	@NotBlank
	private String buyer_add2;
	@NotBlank
	@TelNumber
	private String buyer_comtel;
	@NotBlank
	@TelNumber
	private String buyer_fax;
	@NotBlank
	@Email
	private String buyer_mail;
	@NotBlank
	@Size(max = 4)
	private String buyer_charger;
	private String buyer_telext;

	private ProdVO prod;
	private Set<ProdVO> prodList; // has many
}
