package kr.or.ddit.vo;

import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of="lprod_gu")
public class LprodVO {
	private Integer lprod_id;
	private String lprod_gu;
	private String lprod_nm;
	
	private Set<ProdVO> prodList;
	private BuyerVO buyer;
}
