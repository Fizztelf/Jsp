package kr.or.ddit.taglibs;

import java.util.Calendar;

public class CalendarGenerator {
	public static Calendar generate() {
		return Calendar.getInstance();
	}
}