package kr.or.ddit.mvc;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.member.controller.MemberListController;
import kr.or.ddit.mvc.annotation.HandlerAdapter;
import kr.or.ddit.mvc.annotation.HandlerMapping;
import kr.or.ddit.mvc.annotation.IHandlerAdapter;
import kr.or.ddit.mvc.annotation.IHandlerMapping;
import kr.or.ddit.mvc.annotation.RequestMappingInfo;

/**
 * entry point : 모든 요청이 집중 됨.  POJO(Plain Old Java Object)
 */
public class FrontController extends HttpServlet{
	private IHandlerMapping handlerMapping;
	private IHandlerAdapter hanlderAdapter;
	private IViewResolver viewResolver;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		String basePackage = config.getInitParameter("basePackage");
		handlerMapping = new HandlerMapping(basePackage);
		hanlderAdapter = new HandlerAdapter();
		viewResolver = new ViewResolver();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		
		RequestMappingInfo mappingInfo = handlerMapping.findCommandHandler(req);

		if(mappingInfo==null) { // 제공할 수 있는 서비스가 아직 없음
			resp.sendError(404, "해당 서비스는 지원하지 않음");
			return;
		}
		
		String goPage = hanlderAdapter.invokeHandler(mappingInfo, req, resp);
		
		if(goPage ==null) {
			if(!resp.isCommitted()) { // 응답 데이터가 결정되어서 나가지 않았나?
				resp.sendError(500, "논리적인 뷰네임이 null 일 수 없음!");
			}
			return;
		}
		viewResolver.viewResolve(goPage, req, resp);
	}
}
