package kr.or.ddit.buyer.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import kr.or.ddit.buyer.service.BuyerServiceImpl;
import kr.or.ddit.buyer.service.IBuyerService;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.mvc.annotation.RequestMethod;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.validate.CommonValidator;
import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.vo.BuyerVO;

@Controller
public class BuyerInsertController {
	private IBuyerService service = BuyerServiceImpl.getInstance();
	
	@RequestMapping("/buyer/buyerInsert.do")
	public String doGet() {
		return "buyer/buyerForm";
	}
	
	@RequestMapping(value="/buyer/buyerInsert.do", method=RequestMethod.POST)
	public String doPost(@ModelAttribute("buyer") BuyerVO buyer, HttpServletRequest req) {
		Map<String, List<String>> errors = new LinkedHashMap<>();
		req.setAttribute("errors", errors);
		CommonValidator<BuyerVO> validator = new CommonValidator<>();
		boolean valid = validator.validate(buyer, errors, InsertGroup.class);
		
		String goPage = null;
		
		if(valid) {
			ServiceResult result = service.createBuyer(buyer);
			switch (result) {
			case OK:
				goPage = "redirect:/buyer/buyerList.do";
				break;
			default:
				goPage = "buyer/buyerForm";
				break;
			}
		} else {
			goPage = "buyer/buyerForm";
		}
		return goPage;
	}
}
