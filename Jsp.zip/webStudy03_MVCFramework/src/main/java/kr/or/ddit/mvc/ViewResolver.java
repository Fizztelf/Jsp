package kr.or.ddit.mvc;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewResolver implements IViewResolver {

	@Override
	public void viewResolve(String viewName, HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		boolean redirect = viewName.startsWith("redirect:");
		boolean forward = viewName.startsWith("forward:");
		if(redirect) {
			resp.sendRedirect(req.getContextPath() + viewName.substring("redirect:".length()));
		}else if(forward){
			req.getRequestDispatcher(viewName.substring("forward:".length())).forward(req, resp);
		}else{	
			req.getRequestDispatcher("/"+viewName+".tiles").forward(req, resp);
		}
	}
}
