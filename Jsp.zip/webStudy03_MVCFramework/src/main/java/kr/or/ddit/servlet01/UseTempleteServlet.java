package kr.or.ddit.servlet01;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.utils.TemplateUtils;
/**
 * 서블릿의 콜백 메서드 종류
 * lifecycle callback(singleton) : init, destroy -> 태어날 때 한번, 소멸될 때 한번 호출 -> 어플리케이션 전체를 통틀어 한번씩
 * request callback : service, doXXX -> 요청이 들어올 때마다 반복 호출
 * 	1) service : request의 method 판단 -> 식별 결과에 따라 do[MethodName] 콜백을 호출하여 요청 처리 위임
 * 	2) doXXX : request method에 따라 처리될 구체적인 작업을 정의
 */
public abstract class UseTempleteServlet extends HttpServlet{
	@Override
	protected final void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//doget, dopost 호출 전 단계에서 실행됨, 무조건 실행됨
		resp.setContentType(getMimeType());
		Map<String, Object> dataMap = new HashMap<>();
		
		//tmpl에서 정보가 바뀔 때마다 서블릿 찾아가서 하지 않고
		//여기 서비스 메서드에서 한다고 함
		Map<String, String[]> parameterMap = req.getParameterMap();
		
		//무조건 String 계열로만 넘어가는 문제
//		dataMap.putAll(parameterMap);
		
		//list set 요소 element
		//map 안의 요소 entry (요소 안에 값이 두 개 들어있기 때문)
		for (Entry<String, String[]> entry : parameterMap.entrySet()) {
			String paramName = entry.getKey();//파라미터의 이름
			String[] paramValues = entry.getValue();
			//34행의 문제점 보완을 위해
			dataMap.put(paramName, paramValues.length == 1 ? paramValues[0] : paramValues);
		}
		
		getDataMap(dataMap, req);
		
		String html = TemplateUtils.replaceTemplateToData(req, dataMap);
		
		try(
			PrintWriter out = resp.getWriter();	
		){
			out.println(html);
		}
	}
	public abstract String getMimeType();
	public abstract void getDataMap(Map<String, Object> Map, HttpServletRequest req);
}
