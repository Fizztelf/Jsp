package kr.or.ddit.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TemplateUtils {
	// static -> 객체 생성하지 않아도 쓸 수 있게끔
	public static String readTemplate(HttpServletRequest req) throws IOException {
		// tmpl을 읽어와서 실제 데이터로 바꿔줘야 함.
		// webServlet의 맵핑을 바꿔주었음

		// 파일의 절대경로를 잡아야 하는데 톰캣이 계속 주소를 변경함
		// 위에 맵핑을 해놨는데 여기서 하드코딩이 필요한가?
		String requestURI = req.getRequestURI();
		String cp = req.getContextPath(); // /webStudy01

		String tmpUrl = requestURI.substring(cp.length());
		// 이 url을 토대로 절대 경로를 받아와야 함
		// 서버 웹리소스의 경로 찾기
		URL url = req.getServletContext().getResource(tmpUrl);
		File tmplFile = new File(url.getFile());
//				StringBuffer -> 나눠서 읽고 이걸 누적시키기 위해
		StringBuffer template = new StringBuffer();
		// tmpl 내부에 글이 있을 수 있으므로 charset encoding 설정 필요

		try (FileInputStream fis = new FileInputStream(tmplFile);
				InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
				// InputStreamReader : 1byte와 2byte 연결해주는 역할

				// 버퍼를 가지고 있는 Stream 사용
				BufferedReader reader = new BufferedReader(isr);) {
			String tmp = null;
			while ((tmp = reader.readLine()) != null) {
				template.append(tmp + "\n");
			}
		}
		return template.toString();
	}
	
	//%[a-zA-Z0-9_]+%
	//* = 0번 이상 반복
	//+ = 1번 이상 반복
	static Pattern pattern = Pattern.compile("%([a-zA-Z0-9_]+)%");
	
	public static String replaceTemplateToData(HttpServletRequest request, Map<String, Object> dataMap) throws IOException{
		String template = readTemplate(request);
		Matcher matcher = pattern.matcher(template);
		StringBuffer html = new StringBuffer();
		while(matcher.find()) {
			//Map의 key
			String dataName = matcher.group(1);
			Object data = dataMap.get(dataName);
			//방법 1
//			String value = data == null ? "" : data.toString();
			//방법 2 1.7 이상인 경우
			String value = Objects.toString(data, "");
			matcher.appendReplacement(html, value);
		}
		matcher.appendTail(html);
//		String html = template.replace("%optionData%", dataMap.get("optionData").toString());
//		html = html.replace("%title%", (String)dataMap.get("title"));
//		String html = null;
		return html.toString();
	}
}
