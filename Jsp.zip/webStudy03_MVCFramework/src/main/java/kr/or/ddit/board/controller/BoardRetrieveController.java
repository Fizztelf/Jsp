package kr.or.ddit.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.utils.CookieUtils;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.SearchVO;

@Controller
public class BoardRetrieveController {
   private IBoardService service = BoardServiceImpl.getInstance();
   
   @RequestMapping("/board/boardList.do")
   public String list(
      @RequestParam(value="page", required=false, defaultValue="1") int currentPage
      , @ModelAttribute("searchVO")  SearchVO searchVO ,HttpServletRequest req) {
      PagingVO<BoardVO> pagingVO = new PagingVO<>();
      pagingVO.setSearchVO(searchVO);
      
      int totalRecord = service.retrieveBoardCount(pagingVO);
      pagingVO.setTotalRecord(totalRecord);
      pagingVO.setCurrentPage(currentPage);
      
      List<BoardVO> BoardList = service.retrieveBoardList(pagingVO);
      pagingVO.setDataList(BoardList);
      
      req.setAttribute("pagingVO", pagingVO);
      
      return "board/boardList";
   }
   
   @RequestMapping("/board/boardView.do")
   public String boardView(

         @RequestParam(value="what", required=true) int bo_no
         , HttpServletRequest req) {
         
         BoardVO board = service.retrieveBoard(bo_no);
         req.setAttribute("board", board);
         return "board/boardView";
   }
   
   @RequestMapping("/board/recommend.do")
   public String recommend(
      @RequestParam(value="what", required=true) int bo_no
      , HttpServletRequest req , HttpServletResponse resp
   ) throws IOException, ServletException {
      CookieUtils utils = new CookieUtils(req);
      String value = utils.getCookieValue("boardCookie");
      ObjectMapper mapper = new ObjectMapper();
      
      int[] already = null;
      
      // 무조건 증가시켜선 안됨 현재 글 번호가 추천한 번호와 같지 않으면 수행하지 X
      if(value==null) {
         already = new int[0];
      }else {
         already = mapper.readValue(value, int[].class);         
      }
      Arrays.sort(already);
      ServiceResult result = ServiceResult.FAILED;
      if(Arrays.binarySearch(already, bo_no) < 0) {
         result = service.incrementRecCnt(bo_no);
      }
      
      if(ServiceResult.OK.equals(result)) {
         int[] boardNos = new int[already.length+1];
         System.arraycopy(already, 0, boardNos, 0, already.length);
         boardNos[boardNos.length-1] = bo_no;
         value = mapper.writeValueAsString(boardNos);
         Cookie cookie = CookieUtils.createCookie("boardCookie", value, req.getContextPath(), 60*60*24*3);
         // 세션과 동시에 사라지므로 Max Age필요
         
         resp.addCookie(cookie); // 마샬링된 json을 저장
         // 추천을 누르고 어플리케이션 탭에서 보면 게시글 번호가 저장된 것을 볼 수 있음.
      }
      
      resp.setContentType("text/plain;charset=UTF-8");
      try(
         PrintWriter out = resp.getWriter();   
      ){
         out.println(result.name());
      }
      return null;
   }
}