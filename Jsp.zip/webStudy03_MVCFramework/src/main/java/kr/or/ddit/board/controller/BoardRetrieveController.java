package kr.or.ddit.board.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.SearchVO;

@Controller
public class BoardRetrieveController {
	private IBoardService service = BoardServiceImpl.getInstance();
	
	@RequestMapping("/board/boardList.do")
	public String list(
		@RequestParam(value="page", required=false, defaultValue="1") int currentPage
		, @ModelAttribute("searchVO")  SearchVO searchVO ,HttpServletRequest req) {
		PagingVO<BoardVO> pagingVO = new PagingVO<>();
		pagingVO.setSearchVO(searchVO);
		
		int totalRecord = service.retrieveBoardCount(pagingVO);
		pagingVO.setTotalRecord(totalRecord);
		pagingVO.setCurrentPage(currentPage);
		
		List<BoardVO> BoardList = service.retrieveBoardList(pagingVO);
		pagingVO.setDataList(BoardList);
		
		req.setAttribute("pagingVO", pagingVO);
		
		return "board/boardList";
	}
}
