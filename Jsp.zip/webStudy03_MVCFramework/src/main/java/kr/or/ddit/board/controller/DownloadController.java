package kr.or.ddit.board.controller;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.enumpkg.Browser;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.vo.AttatchVO;

@Controller
public class DownloadController {
	private IBoardService service = BoardServiceImpl.getInstance();
	private File saveFolder;
	{
		saveFolder = new File("d:/saveFiles");
		if(!saveFolder.exists()) {
			saveFolder.mkdirs();
		}
	}
	
	@RequestMapping("/board/download.do")
	public String download(
		@RequestParam(value="what", required=true) int att_no
		, HttpServletResponse resp
		, HttpServletRequest req
	) throws IOException {
//		Content-Disposition: attatchment; filename=""
		String agent = req.getHeader("User-Agent");
		Browser browser = Browser.getBrowserConstant(agent);
		AttatchVO attatch = service.download(att_no);
		String savename = attatch.getAtt_savename();
		String filename = attatch.getAtt_filename();
		if(Browser.TRIDENT.equals(browser)) {
			filename = URLEncoder.encode(filename, "UTF-8").replace("+", "%20");
		}else {
			byte[] bytes = filename.getBytes();
			filename = new String(bytes, "ISO-8859-1");
			System.out.println("===============>"+filename);
		}
		resp.setHeader("Content-Disposition", "attatchment;filename=\""+filename+"\"");
		File saveFile = new File(saveFolder, savename);
		resp.setContentType("application/octet-stream");
		try(
			OutputStream os = resp.getOutputStream();	
		){
			FileUtils.copyFile(saveFile, os);
		}
		return null;
	}
}
