package kr.or.ddit.reply.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ReplyVO;

public class ReplyDAOImpl implements IReplyDAO {

	private ReplyDAOImpl() { }
	private static ReplyDAOImpl self;
	public static ReplyDAOImpl getInstance() {
		if(self==null) self = new ReplyDAOImpl();
		return self;
	}
	
	private SqlSessionFactory sqlSessionFactory = 
			CustomSqlSessionFactoryBuilder.getSqlSessionFactory();
	
	@Override
	public int insertReply(ReplyVO reply) {
		try(
			SqlSession sqlSession = sqlSessionFactory.openSession();
		){
			IReplyDAO mapper = sqlSession.getMapper(IReplyDAO.class);
			return mapper.insertReply(reply);
		}
	}

	@Override
	public int selectReplyCount(PagingVO<ReplyVO> paging) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ReplyVO> selectReplyList(PagingVO<ReplyVO> paging) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReplyVO selectReply(int rep_no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateReply(ReplyVO reply) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteReply(int rep_no) {
		// TODO Auto-generated method stub
		return 0;
	}

}
