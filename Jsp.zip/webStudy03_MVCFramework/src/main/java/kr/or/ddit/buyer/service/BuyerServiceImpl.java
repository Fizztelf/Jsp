package kr.or.ddit.buyer.service;

import java.util.List;

import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.buyer.dao.BuyerDAOImpl;
import kr.or.ddit.buyer.dao.IBuyerDAO;
import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.vo.BuyerVO;
import kr.or.ddit.vo.PagingVO;

public class BuyerServiceImpl implements IBuyerService {
	private BuyerServiceImpl() {}
	private static BuyerServiceImpl self;
	public static BuyerServiceImpl getInstance() {
		if(self==null) self = new BuyerServiceImpl();
		return self;
	}
	
	private IBuyerDAO dao = BuyerDAOImpl.getInstance();
	
	@Override
	public ServiceResult createBuyer(BuyerVO buyer) {
		int rowcnt = dao.insertBuyer(buyer);
		ServiceResult result = ServiceResult.FAILED;
		
		if(rowcnt>0) {
			result = ServiceResult.OK;
		}
		return result;
	}

	@Override
	public int retrieveBuyerCount(PagingVO<BuyerVO> pagingVO) {
		return dao.selectBuyerCount(pagingVO);
	}

	@Override
	public List<BuyerVO> retrieveBuyerList(PagingVO pagingVO) {
		return dao.selectBuyerList(pagingVO);
	}

	@Override
	public BuyerVO retrieveBuyer(String buyer_id) {
		return dao.selectBuyer(buyer_id);
	}

	@Override
	public ServiceResult modifyBuyer(BuyerVO buyer) {
		int rowcnt = dao.updateBuyer(buyer);
		ServiceResult result = ServiceResult.FAILED;
		
		if(rowcnt > 0) {
			result = ServiceResult.OK;
		}
		return result;
	}
	

}
