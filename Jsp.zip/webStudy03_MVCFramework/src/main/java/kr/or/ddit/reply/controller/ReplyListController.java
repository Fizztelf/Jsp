package kr.or.ddit.reply.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.reply.service.IReplyService;
import kr.or.ddit.reply.service.ReplySerivceImpl;
import kr.or.ddit.utils.JsonResponseUtils;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ReplyVO;

@Controller
public class ReplyListController {
	private static final Logger logger = LoggerFactory.getLogger(ReplyListController.class);
	private IReplyService service = ReplySerivceImpl.getInstance();
	
	@RequestMapping("/reply/replyList.do")
	public String replyList(@RequestParam(value="page", required=false, defaultValue="1")int currentPage,
			HttpServletRequest req, HttpServletResponse resp
			) throws IOException {
		
		PagingVO<ReplyVO> pagingVO = new PagingVO<>(7, 3);
		// 목록 조회와 카운트 조회시 동일 검색 조건 사용.
		
		int totalRecord = service.retrieveReplyCount(pagingVO);
		pagingVO.setTotalRecord(totalRecord);
		pagingVO.setCurrentPage(currentPage);
		
		List<ReplyVO> replyList = service.retrieveReplyList(pagingVO);
		pagingVO.setDataList(replyList);
		
		req.setAttribute("paging", pagingVO);
		
		String accept = req.getHeader("Accept");
		if(StringUtils.containsIgnoreCase(accept, "json")) {
			JsonResponseUtils.toJsonResponse(req, resp);
			return null;
		}else {
			return "board/boardView";
		}
	}
}
