package kr.or.ddit.dbprop.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.ddit.db.ConnectionFactory;
import kr.or.ddit.dbprop.dao.DataBasePropertyDAO;
import kr.or.ddit.dbprop.service.DataBasePropertyService;
import kr.or.ddit.dbprop.service.IDataBasePropertyService;
import kr.or.ddit.utils.JsonResponseUtils;
import kr.or.ddit.vo.DataBasePropertyVO;

@WebServlet("/08/jdbcDesc.do")
public class DataBasePropertyServlet extends HttpServlet {
	IDataBasePropertyService service = new DataBasePropertyService();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String property_name = req.getParameter("property_name");
		String property_value = req.getParameter("property_value");
		String description = req.getParameter("description");
		
		DataBasePropertyVO paramVO = DataBasePropertyVO.builder()
				.property_name(property_name)
				.property_value(property_value)
				.description(description)
				.build();
		
		List<DataBasePropertyVO> list = service.retrieveDataBaseProperty(paramVO);
		
		req.setAttribute("dbProps", list);
		
		String accept = req.getHeader("Accept");
		
		if(accept.contains("json")) {
			JsonResponseUtils.toJsonResponse(req, resp);
		} else {
			String logicalView = "08/jdbcDesc";
			req.getRequestDispatcher("/WEB-INF/views/" + logicalView + ".jsp").forward(req, resp);
		}
	}
}
