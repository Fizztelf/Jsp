package kr.or.ddit.board.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.CustomException;
import kr.or.ddit.board.dao.AttatchDAOImpl;
import kr.or.ddit.board.dao.BoardDAOImpl;
import kr.or.ddit.board.dao.IAttatchDAO;
import kr.or.ddit.board.dao.IBoardDAO;
import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.utils.SecurityUtils;
import kr.or.ddit.vo.AttatchVO;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.PagingVO;

public class BoardServiceImpl implements IBoardService {
	private BoardServiceImpl() { }
	private static BoardServiceImpl self;
	public static BoardServiceImpl getInstance() {
		if(self==null) self = new BoardServiceImpl();
		return self;
	}
	private IBoardDAO boardDAO = BoardDAOImpl.getInstance();
	private IAttatchDAO attDAO  = AttatchDAOImpl.getInstance();
	
	private File saveFolder;
	{
		saveFolder = new File("d:/saveFiles");
		if(!saveFolder.exists()) {
			saveFolder.mkdirs();
		}
	}
	
	private void encodePassword(BoardVO board) {
		String encoded = SecurityUtils.encryptSha512(board.getBo_pass());
		board.setBo_pass(encoded);
	}

	private SqlSessionFactory sqlSessionFactory = CustomSqlSessionFactoryBuilder.getSqlSessionFactory();
	
	@Override
	public ServiceResult createBoard(BoardVO board) {
		try(
			SqlSession sqlSession = sqlSessionFactory.openSession();
		){
			encodePassword(board);
			int cnt = boardDAO.insertBoard(board, sqlSession);
			if(cnt > 0) {
				cnt += processAttatches(board, sqlSession);
			}
			ServiceResult result = null;
			if(cnt > 0) {
				result = ServiceResult.OK;
				sqlSession.commit();
			}else {
				result = ServiceResult.FAILED;
			}
			return result;
		}
	}

	private int processAttatches(BoardVO board, SqlSession sqlSession) { 
		List<AttatchVO> attatchList = board.getAttatchList();
		int cnt = 0;
		if(attatchList != null && !attatchList.isEmpty() ) { // 첨부파일이 한 건이라도 있으면
			cnt += attDAO.insertAttaches(board, sqlSession);
			try {
				for(AttatchVO attatch : attatchList) {	// 2진 데이터 저장
					attatch.saveTo(saveFolder);
				}	
			}catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return cnt;
	}
	

	@Override
	public int retrieveBoardCount(PagingVO<BoardVO> paging) {
		return boardDAO.selectBoardCount(paging);
	}

	@Override
	public List<BoardVO> retrieveBoardList(PagingVO<BoardVO> paging) {
		return boardDAO.selectBoardList(paging);
	}

	@Override
	public BoardVO retrieveBoard(int bo_no) {
		BoardVO board = boardDAO.selectBoard(bo_no);
		if(board==null) throw new CustomException(bo_no+"번 글이 없음");
		boardDAO.incrementHit(bo_no);
		return board;
	}

	@Override
	public ServiceResult modifyBoard(BoardVO board) {
		try(
			SqlSession sqlSession = sqlSessionFactory.openSession();
		){
			encodePassword(board);
			int cnt = boardDAO.updateBoard(board, sqlSession);
			if(cnt > 0) {
				cnt += processAttatches(board, sqlSession); 
			}
			ServiceResult result = null;
			if(cnt > 0) {
				result = ServiceResult.OK;
				sqlSession.commit();
			} else {
				result = ServiceResult.FAILED;
			}
			return result;
		}
	}

	@Override
	public ServiceResult removeBoard(BoardVO board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AttatchVO download(int att_no) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult incrementRecCnt(int bo_no) {
		int cnt = boardDAO.incrementRecCnt(bo_no);
		return cnt>0 ? ServiceResult.OK : ServiceResult.FAILED;
	}

}
