package kr.or.ddit.board.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import kr.or.ddit.board.dao.AttatchDAOImpl;
import kr.or.ddit.board.dao.BoardDAOImpl;
import kr.or.ddit.board.dao.IAttatchDAO;
import kr.or.ddit.board.dao.IBoardDAO;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.utils.SecurityUtils;
import kr.or.ddit.vo.AttatchVO;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.PagingVO;

public class BoardServiceImpl implements IBoardService {
	private BoardServiceImpl() { }
	private static BoardServiceImpl self;
	public static BoardServiceImpl getInstance() {
		if(self==null) self = new BoardServiceImpl();
		return self;
	}
	private IBoardDAO boardDAO = BoardDAOImpl.getInstance();
	private IAttatchDAO attDAO  = AttatchDAOImpl.getInstance();
	
	private File saveFolder;
	{
		saveFolder = new File("d:/saveFiles");
		if(!saveFolder.exists()) {
			saveFolder.mkdirs();
		}
	}
	
	private void encodePassword(BoardVO board) {
		String encoded = SecurityUtils.encryptSha512(board.getBo_pass());
		board.setBo_pass(encoded);
	}

	@Override
	public ServiceResult createBoard(BoardVO board) {
		encodePassword(board);
		int cnt = boardDAO.insertBoard(board);
		if(cnt > 0) {
			cnt += processAttatches(board);
		}
		ServiceResult result = null;
		if(cnt > 0) {
			result = ServiceResult.OK;
		}else {
			result = ServiceResult.FAILED;
		}
		return result;
	}

	private int processAttatches(BoardVO board) {
		List<AttatchVO> attatchList = board.getAttatchList();
		int cnt = 0;
		if(attatchList != null && !attatchList.isEmpty() ) {
			cnt += attDAO.insertAttaches(board);
			try {
				for(AttatchVO attatch : attatchList) {
					attatch.saveTo(saveFolder);
				}	
			}catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return cnt;
	}
	
	
	
	
	

	@Override
	public int retrieveBoardCount(PagingVO<BoardVO> paging) {
		return boardDAO.selectBoardCount(paging);
	}

	@Override
	public List<BoardVO> retrieveBoardList(PagingVO<BoardVO> paging) {
		return boardDAO.selectBoardList(paging);
	}

	@Override
	public BoardVO retrieveBoard(int bo_no) {
		return boardDAO.selectBoard(bo_no);
	}

	@Override
	public ServiceResult modifyBoard(BoardVO board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult removeBoard(BoardVO board) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AttatchVO download(int att_no) {
		// TODO Auto-generated method stub
		return null;
	}

}
