package kr.or.ddit.reply.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.mvc.annotation.RequestMethod;
import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.reply.service.IReplyService;
import kr.or.ddit.reply.service.ReplySerivceImpl;
import kr.or.ddit.validate.CommonValidator;
import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.NotyMessageVO;
import kr.or.ddit.vo.ReplyVO;

@Controller
public class ReplyInsertController {
	private IReplyService service = ReplySerivceImpl.getInstance();
	
	@RequestMapping("/reply/replyInsert.do")
	public String form() {
		return "board/boardView";
	}
	
	@RequestMapping(value="/reply/replyInsert.do", method=RequestMethod.POST)
	public String insert(
			@RequestParam(value="rep_writer", required=true) String rep_writer,
			@RequestParam(value="rep_content", required=true) String rep_content,
			@RequestParam(value="rep_pass", required=true) String rep_pass,
			@ModelAttribute("reply") ReplyVO reply, HttpServletRequest req) {
		
		Map<String, List<String>> errors = new LinkedHashMap<>();
		req.setAttribute("errors", errors);
		CommonValidator<ReplyVO> validator = new CommonValidator<>();
		boolean valid = validator.validate(reply, errors, InsertGroup.class);
		
		String goPage = null;
		
		ReplyVO rep = new ReplyVO();
		rep.setRep_writer(rep_writer);
		rep.setRep_content(rep_content);
		rep.setRep_pass(rep_pass);
		
		if(valid) {
			ServiceResult result = service.createReply(reply);
			switch (result) {
			case OK:
				goPage = "redirect:/board/boardView.do"+reply.getRep_no();
				break;
			default:
				req.setAttribute("message", NotyMessageVO.builder("서버 오류").build());
				break;
			}
		} else {
			goPage = "board/boardView";
		}
		return goPage;
	}
}
