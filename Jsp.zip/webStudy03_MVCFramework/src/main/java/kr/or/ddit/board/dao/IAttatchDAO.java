package kr.or.ddit.board.dao;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.vo.AttatchVO;
import kr.or.ddit.vo.BoardVO;

public interface IAttatchDAO {
	public int insertAttaches(BoardVO board, SqlSession sqlSession);
	public int deleteAttatches(BoardVO board);
	public AttatchVO selectAttach(int att_no);
	public int incrementDownCount(int att_no);
}
