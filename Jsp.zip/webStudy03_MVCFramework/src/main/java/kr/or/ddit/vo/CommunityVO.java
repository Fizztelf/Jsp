package kr.or.ddit.vo;

import lombok.Data;

@Data
public class CommunityVO {

	private String writer_id            ;
	private String writer_date          ;
	private String writer_suggestions   ;
	
}
