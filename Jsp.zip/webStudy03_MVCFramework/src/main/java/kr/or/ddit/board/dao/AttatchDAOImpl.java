package kr.or.ddit.board.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.vo.AttatchVO;
import kr.or.ddit.vo.BoardVO;

public class AttatchDAOImpl implements IAttatchDAO {
	private AttatchDAOImpl() { }
	private static AttatchDAOImpl self;
	public static AttatchDAOImpl getInstance() {
		if(self==null) self = new AttatchDAOImpl();
		return self;
	}
	
	private SqlSessionFactory sqlSessionFactory = 
			CustomSqlSessionFactoryBuilder.getSqlSessionFactory();

	@Override
	public int insertAttaches(BoardVO board, SqlSession sqlSession) {
		return sqlSession.insert("kr.or.ddit.board.dao.AttatchDAOImpl.insertAttaches",board);
	}

	@Override
	public int deleteAttatches(BoardVO board) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public AttatchVO selectAttach(int att_no) {
		try (
			SqlSession sqlSession = sqlSessionFactory.openSession(true);
		) {
			IAttatchDAO mapper = sqlSession.getMapper(IAttatchDAO.class);
			return mapper.selectAttach(att_no);
		}
	}

	@Override
	public int incrementDownCount(int att_no) {
		// TODO Auto-generated method stub
		return 0;
	}

}
