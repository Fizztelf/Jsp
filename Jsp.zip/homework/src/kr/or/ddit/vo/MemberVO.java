package kr.or.ddit.vo;

import java.io.Serializable;

public class MemberVO implements Serializable{
	private String mail; // 메일
	private String name; // 이름
	private String pass; // 패스워드
	
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public MemberVO(String mail, String name, String pass) {
		super();
		this.mail = mail;
		this.name = name;
		this.pass = pass;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mail == null) ? 0 : mail.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((pass == null) ? 0 : pass.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MemberVO other = (MemberVO) obj;
		if (mail == null) {
			if (other.mail != null)
				return false;
		} else if (!mail.equals(other.mail))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (pass == null) {
			if (other.pass != null)
				return false;
		} else if (!pass.equals(other.pass))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "MemberVO [mail=" + mail + ", name=" + name + ", pass=" + pass + "]";
	}
	
	public static MemberVOBuilder getBuilder() {
		return new MemberVOBuilder();
	}
	public static class MemberVOBuilder {
		private String mail;
		private String name;
		private String pass;
		
		public MemberVOBuilder mail(String mail) {
			this.mail = mail;
			return this;
		}
		public MemberVOBuilder name(String name) {
			this.name = name;
			return this;
		}
		public MemberVOBuilder pass(String pass) {
			this.pass = pass;
			return this;
		}
		
		public MemberVO build() {
			return new MemberVO(mail, name, pass);
		}
	}
	
}
