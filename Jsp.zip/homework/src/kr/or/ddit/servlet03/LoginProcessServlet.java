package kr.or.ddit.servlet03;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/login/loginProcess.do")
public class LoginProcessServlet extends HttpServlet{
	private boolean authenticate(String mem_id, String mem_pass) {
		return mem_id.equals(mem_pass);
	}
	
//	private boolean validate(String mem_id, String mem_pass) {
//		
//	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String mem_id = req.getParameter("mem_id");
		String mem_pass = req.getParameter("mem_pass");
		
//		if(validate(mem_id, mem_pass)) {
//			
//		}
		
//		if(StringUtils.isBlank(mem_id) || StringUtils.isBlank(mem_pass)) {
//			resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "아이디 또는 비밀번호 누락");
//			return;
//		}
		
		HttpSession session = req.getSession();
		
		if(authenticate(mem_id, mem_pass)) {
			session.setAttribute("authMember",mem_id);
			resp.sendRedirect(req.getContextPath());
		} else {
			session.setAttribute("mem_id", mem_id);
//			req.getRequestDispatcher("/login/loginForm.jsp").forward(req, resp);
			resp.sendRedirect(req.getContextPath()+"/login/loginForm.jsp");
		}
	}
}
