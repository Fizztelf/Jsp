package kr.or.ddit.enumpkg;

public enum OperateType {

	PLUS('+', (l, r)->{return l+r;}),
	MINUS('-', (l, r) -> {return l-r;}),
	MULTIPLY('*', (l,r) -> {return l*r;}),
	DIVIDE('/', (l, r) -> {return l/r;}),
	MODULAR('%', (l, r) -> {return 1%r;});
		
		@FunctionalInterface
		public static interface RealOperator{
			public int operate(int leftOp, int rightOp);
//			인터페이스와 함수의 개수가 일치한다. -> 기능적 함수 인터페이스
//			한 개의 인터페이스에서 한 개의 기능을 가진다. -> 람다식 변환 가능		
		}
		private char sign;
		private RealOperator realOperator;
		
		private OperateType(char sign, RealOperator realOperator) {
			this.sign = sign;
			this.realOperator = realOperator;
		}
		
		public char getSign() {
			return sign;
		}
		
		public int operator(int leftOp, int rightOp) {
			//상수에 의해서 객체가 결정이 될 때, 객체가 하는 일도 결정해줘야하 한다.
			return realOperator.operate(leftOp, rightOp);
			//연산에 대한 책임은 RealOperator로 넘어간다.
		}
		
	
	
}
