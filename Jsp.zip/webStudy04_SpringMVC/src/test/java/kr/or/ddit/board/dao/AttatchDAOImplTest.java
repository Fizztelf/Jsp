package kr.or.ddit.board.dao;

import static org.junit.Assert.fail;

import java.util.Arrays;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import kr.or.ddit.CustomWebAppConfiguration;
import kr.or.ddit.vo.AttatchVO;
import kr.or.ddit.vo.BoardVO;


@RunWith(SpringRunner.class)
@CustomWebAppConfiguration
public class AttatchDAOImplTest {
	@Inject
	IAttatchDAO dao;

//	@Test
	public void testGetInstance() {
		fail("Not yet implemented");
	}

	@Test
	public void testInsertAttaches() {
		BoardVO board = new BoardVO();
		board.setBo_no(320);
		AttatchVO att = new AttatchVO();
		att.setAtt_savename("test");
		board.setAttatchList(Arrays.asList(att));
		dao.insertAttaches(board);		
	}

//	@Test
	public void testDeleteAttatches() {
		fail("Not yet implemented");
	}

//	@Test
	public void testSelectAttach() {
		fail("Not yet implemented");
	}

}
