package kr.or.ddit.member.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import kr.or.ddit.CustomWebAppConfiguration;
import kr.or.ddit.vo.MemberVO;
@RunWith(SpringJUnit4ClassRunner.class)
@CustomWebAppConfiguration
public class MemberDAOImplTest {
	@Inject
	private IMemberDAO dao;
	private String mem_id;
	@Before
	public void setup() {
		System.out.println("setup");
		mem_id = "c001";
	}

//	@Test
//	public void testSelectMember() {
//		MemberVO member = dao.selectMember("a001");
//		assertNotNull(member);
//	}
//
//	@Test
//	public void testInsertMember() {
////		MemberVO member = new MemberVO();
////		member.setMem_id("b000");
////		dao.insertMember(member);
//	}
//
//	@Test
//	public void testSelectMemberList() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testUpdateMember() {
//		fail("Not yet implemented");
//	}

	@Test
	public void testDeleteMember() {
		int rowcnt = dao.deleteMember(mem_id);
		assertEquals(1, rowcnt);
	}

}














