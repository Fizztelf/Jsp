package kr.or.ddit.commons.dao;

import static org.junit.Assert.assertNotEquals;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import kr.or.ddit.CustomWebAppConfiguration;
import kr.or.ddit.vo.ZipVO;
@RunWith(SpringRunner.class)
@CustomWebAppConfiguration
public class SearchZipDAOImplTest {

	@Inject
	private ISearchZipDAO dao;
	
	@Test
	public void testSelectZipList() {
		List<ZipVO> zipList = dao.selectZipList(null);
		assertNotEquals(0, zipList.size());
	}

}












