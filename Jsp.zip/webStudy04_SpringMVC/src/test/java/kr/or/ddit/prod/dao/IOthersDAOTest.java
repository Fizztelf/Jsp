package kr.or.ddit.prod.dao;

import java.util.List;
import java.util.Map;

import org.junit.Test;

import kr.or.ddit.vo.BuyerVO;

public class IOthersDAOTest {
	private IOthersDAO dao = OthersDAOImpl.getInstance();

	@Test
	public void testSelectLprodList() {
		List<Map<String, Object>> lprodList = dao.selectLprodList();
		System.out.println(lprodList);
	}

	@Test
	public void testSelectBuyerList() {
		List<BuyerVO> buyerList = dao.selectBuyerList();
		System.out.println(buyerList);
	}

}












