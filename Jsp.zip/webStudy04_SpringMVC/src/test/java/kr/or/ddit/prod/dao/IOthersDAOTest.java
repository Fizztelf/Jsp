package kr.or.ddit.prod.dao;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import kr.or.ddit.CustomWebAppConfiguration;
import kr.or.ddit.vo.BuyerVO;

@RunWith(SpringRunner.class)
@CustomWebAppConfiguration
public class IOthersDAOTest {
	@Inject
	private IOthersDAO dao;

	@Test
	public void testSelectLprodList() {
		List<Map<String, Object>> lprodList = dao.selectLprodList();
		System.out.println(lprodList);
	}

	@Test
	public void testSelectBuyerList() {
		List<BuyerVO> buyerList = dao.selectBuyerList();
		System.out.println(buyerList);
	}

}












