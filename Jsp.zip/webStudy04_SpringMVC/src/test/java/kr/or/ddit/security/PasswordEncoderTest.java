package kr.or.ddit.security;

import static org.junit.Assert.assertEquals;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import kr.or.ddit.CustomWebAppConfiguration;

@RunWith(SpringRunner.class)
@CustomWebAppConfiguration
//@ContextConfiguration("file:webapp/WEB-INF/spring/*-context.xml")
//@WebAppConfiguration
//@Transactional
public class PasswordEncoderTest {
	
	@Inject
	PasswordEncoder passwordEncoder;

	@Test
	public void test() {
		String plain = "abAB1";
		String saved = "{bcrypt}$2a$10$D0D7/kpWgkNmRqASpsa6PeIKA9z79Boy40llxdGS.IuaMDyrOOLbm";
		boolean matched = passwordEncoder.matches(plain, saved);
		assertEquals(true, matched);
//		String encoded = passwordEncoder.encode(plain);
//		System.out.println(encoded);		
	}

}





























