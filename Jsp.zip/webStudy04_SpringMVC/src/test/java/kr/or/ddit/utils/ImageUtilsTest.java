package kr.or.ddit.utils;

import static org.junit.Assert.fail;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;

import org.junit.BeforeClass;
import org.junit.Test;

public class ImageUtilsTest {

	private static File image;
	
	@BeforeClass
	public static void setUp() throws Exception {
		 image = new File(ImageUtilsTest.class.getResource("cat1.jpg").getFile());
	}

	@Test
	public void testImageSize() throws IOException {
		Dimension size = ImageUtils.imageSize(image);
		System.out.println(size);
	}

	@Test
	public void testResize() throws IOException {
		String newName = "cat1_thumnail1.jpg";
		File dest = new File(ImageUtilsTest.class.getResource("").getFile(), newName);
		ImageUtils.resize(image, dest, 320, ImageUtils.RATIO);
		Dimension newSize = ImageUtils.imageSize(dest);
		System.out.println(newSize);
		newName = "cat1_thumnail2.jpg";
		dest = new File(ImageUtilsTest.class.getResource("").getFile(), newName);
		ImageUtils.resize(image, dest, ImageUtils.RATIO, 300);
		newSize = ImageUtils.imageSize(dest);
		System.out.println(newSize);
	}

}
