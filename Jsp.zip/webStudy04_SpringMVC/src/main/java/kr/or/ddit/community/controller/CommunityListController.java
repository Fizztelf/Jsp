package kr.or.ddit.community.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.or.ddit.community.service.ICommunityService;
import kr.or.ddit.vo.CommunityVO;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.SearchVO;

@Controller
@RequestMapping("community/communityList.do")
public class CommunityListController {
	
	@Resource(type=ICommunityService.class)
	private ICommunityService service;
	
	public String ComList(@RequestParam(value="page", required=false, defaultValue="1") int currentPage,
			@ModelAttribute("searchVO") SearchVO searchVO, Model model) {
		
		PagingVO<CommunityVO> pagingVO = new PagingVO<>(5,2);
		pagingVO.setSearchVO(searchVO);
		
		int totalRecord = service.retrieveCommunityCount(pagingVO);
		pagingVO.setTotalRecord(totalRecord);
		pagingVO.setCurrentPage(currentPage);
		
		List<CommunityVO> comList = service.retrieveCommunityList(pagingVO);
		pagingVO.setDataList(comList);
		
		model.addAttribute("pagingVO", pagingVO);
		
		return "community/communityList";
		
		}
	@RequestMapping(produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public PagingVO<CommunityVO> comListForAjax(@RequestParam(value="page", required=false, defaultValue="1") int currentPage
			, @ModelAttribute("searchVO") SearchVO searchVO
			, Model model){
		return (PagingVO<CommunityVO>) model.asMap().get("pagingVO");
	}
	
}
