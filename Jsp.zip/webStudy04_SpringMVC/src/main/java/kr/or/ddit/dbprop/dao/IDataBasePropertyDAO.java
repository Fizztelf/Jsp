package kr.or.ddit.dbprop.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import kr.or.ddit.vo.DataBasePropertyVO;

@Repository
public interface IDataBasePropertyDAO {

	List<DataBasePropertyVO> selectDBProperties(DataBasePropertyVO paramVO);

}