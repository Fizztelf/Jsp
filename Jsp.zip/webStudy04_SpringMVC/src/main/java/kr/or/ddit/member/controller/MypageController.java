package kr.or.ddit.member.controller;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.ddit.member.service.IAuthenticateService;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.MemberWrapper;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
@RequestMapping("/mypage.do")
public class MypageController{
//	@Inject
//	private IAuthenticateService service;
	
	@GetMapping
	public String doGet(){
		return "member/passwordForm";
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping
	public String doPost(
			@RequestParam("mem_pass") String mem_pass
			, @AuthenticationPrincipal(expression="realMember") MemberVO authMember , Model model ){
		
		String goPage = null;
		model.addAttribute("member", authMember);
		goPage = "member/mypage";
		return goPage;
	}
	
}
















