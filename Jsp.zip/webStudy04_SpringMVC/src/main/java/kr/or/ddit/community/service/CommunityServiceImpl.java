package kr.or.ddit.community.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import kr.or.ddit.community.dao.ICommunityDAO;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.vo.CommunityVO;
import kr.or.ddit.vo.PagingVO;

@Service
public class CommunityServiceImpl implements ICommunityService {

	@Inject
	private ICommunityDAO dao;
	
	@Override
	public ServiceResult registerCommunity(CommunityVO com) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int retrieveCommunityCount(PagingVO pagingVO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<CommunityVO> retrieveCommunityList(PagingVO pagingVO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CommunityVO retrieveCommunity(String writer_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult modifyCommunity(CommunityVO com) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult removeCommunity(CommunityVO com) {
		// TODO Auto-generated method stub
		return null;
	}

}
