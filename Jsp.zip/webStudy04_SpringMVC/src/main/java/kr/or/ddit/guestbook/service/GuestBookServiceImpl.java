package kr.or.ddit.guestbook.service;

import java.util.List;

import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.guestbook.dao.IGuestBookDAO;
import kr.or.ddit.utils.SecurityUtils;
import kr.or.ddit.vo.GuestBookVO;
import kr.or.ddit.vo.PagingVO;

@Service
public class GuestBookServiceImpl implements IGuestBookService {
	
	@Inject
	IGuestBookDAO gbDAO;
	
	private void encryptPassword(GuestBookVO guestBook) {
	 	String inputPass = guestBook.getGb_pass();
	 	if(StringUtils.isNotBlank(inputPass)) {
	 		guestBook.setGb_pass(SecurityUtils.encryptSha512(inputPass));
	 	}
	}
	
	@Override
	public ServiceResult createGuestBook(GuestBookVO guestBook) {
		encryptPassword(guestBook);
		int rowCnt = gbDAO.insertGuestBook(guestBook);
		ServiceResult result = ServiceResult.FAILED;
		if(rowCnt > 0) result = ServiceResult.OK;
		return result;
	}

	@Override
	public int retrieveGuestBookCount(PagingVO<GuestBookVO> pagingVO) {
		return gbDAO.selectGuestBookCount(pagingVO);
	}

	@Override
	public List<GuestBookVO> retrieveGuestBookList(PagingVO<GuestBookVO> pagingVO) {
		return gbDAO.selectGuestBookList(pagingVO);
	}
	
	@Override
	public GuestBookVO retrieveGuestBook(GuestBookVO guestBook) {
		encryptPassword(guestBook);
		return gbDAO.selectGuestBook(guestBook);
	}

	@Override
	public ServiceResult modifyGuestBook(GuestBookVO guestBook) {
		encryptPassword(guestBook);
		int rowCnt = gbDAO.updateGuestBook(guestBook);
		ServiceResult result = ServiceResult.INVALIDPASSWORD;
		if(rowCnt > 0) result = ServiceResult.OK;
		return result;
	}

	@Override
	public ServiceResult removeGuestBook(GuestBookVO guestBook) {
		encryptPassword(guestBook);
		int rowCnt = gbDAO.deleteGuestBook(guestBook);
		ServiceResult result = ServiceResult.INVALIDPASSWORD;
		if(rowCnt > 0) result = ServiceResult.OK;
		return result;
	}

}
