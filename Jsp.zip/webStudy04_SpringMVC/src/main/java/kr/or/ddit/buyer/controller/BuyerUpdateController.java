package kr.or.ddit.buyer.controller;

import java.io.IOException;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.ddit.buyer.service.IBuyerService;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.validate.groups.UpdateGroup;
import kr.or.ddit.vo.BuyerVO;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
@RequestMapping("/buyer/buyerUpdate.do")
public class BuyerUpdateController {
	
	@Inject
	private IBuyerService service;
	
	@ModelAttribute("currentAction")
	public String addAttribute() {
		return "/buyer/buyerUpdate.do";
	}
    
	@GetMapping
	public String form(@RequestParam("what") String buyer_id, Model model){
		BuyerVO buyer = service.retrieveBuyer(buyer_id);
		model.addAttribute("buyer", buyer);
		return "buyer/buyerForm";
	}
	
	@PostMapping
	public String update(
		@Validated(UpdateGroup.class) @ModelAttribute("buyer") BuyerVO buyer
		, Errors errors
		, Model model
			) throws IOException{
		
		boolean valid = !errors.hasErrors();
		
		String goPage = null;
		
		if (valid) {
//		2. 로직 선택 service.modifybuyer(buyer)
			ServiceResult result = service.modifyBuyer(buyer);
//		3. 로직의 실행 결과에 따른 분기 페이지 선택
			switch (result) {
			case OK:
				goPage = "redirect:/buyer/buyerView.do?what="+buyer.getBuyer_id();
				break;
			default: // FAIL
				model.addAttribute("message", NotyMessageVO.builder("서버 오류").build());
				goPage = "buyer/buyerForm";
				break;
			}
		} else {
			goPage = "buyer/buyerForm";
		}
//		4. 모델 데이터 공유
		return goPage;
	}
}