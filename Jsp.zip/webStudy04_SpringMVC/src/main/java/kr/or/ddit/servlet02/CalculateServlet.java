package kr.or.ddit.servlet02;

import java.util.Date;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.ddit.enumpkg.OperateType;

@Controller
@RequestMapping("/03/calculate.do")
public class CalculateServlet{
	
	@PostMapping
	public String html(
		@RequestParam(required=true) int leftOp, 
		@RequestParam(required=true) int rightOp, 
		@RequestParam(name="operator", required=true) OperateType operator
		, Model model){
		
		json(leftOp, rightOp, operator, model);
		return "calculate";
	}
	@PostMapping(produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public String json(
			@RequestParam(required=true) int leftOp, 
			@RequestParam(required=true) int rightOp, 
			@RequestParam(name="operator", required=true) OperateType operator
			, Model model){
		int result = operator.operator(leftOp, rightOp);
		
		String exprPtrn = "%d %s %d = %d";
		String responseData = String.format(exprPtrn, leftOp, operator.getSign(), rightOp, result);
		Date now = new Date();
		model.addAttribute("data", responseData);
		model.addAttribute("now", now);
		return "jsonView";
	}

	
}










