package kr.or.ddit.member.controller;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.CookieClearingLogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
public class MemberDeleteController{
	@Inject
	private IMemberService service;
//	@Inject
//	private LogoutHandler logoutHandler;
	
			
	@PostMapping(value="/member/removeMember.do")
	public String doPost(@RequestParam("mem_pass") String mem_pass 
			, @AuthenticationPrincipal(expression="realMember") MemberVO authMember
			, RedirectAttributes redirectAttributes
			, HttpServletRequest req, HttpServletResponse resp
			, Authentication authentication) {
		
		String mem_id = authMember.getMem_id();
		ServiceResult result = service.removeMember(MemberVO.builder()
															.mem_id(mem_id)
															.mem_pass(mem_pass)
															.build());
		
		String goPage = null;
		switch (result) {
		case INVALIDPASSWORD:
			redirectAttributes.addFlashAttribute("message", NotyMessageVO.builder("비번 오류:").build());
			goPage = "redirect:/mypage.do";
			break;
		case FAILED:
			redirectAttributes.addFlashAttribute("message", NotyMessageVO.builder("서버 오류:").build());
			goPage = "redirect:/mypage.do";
			break;
		default:
			LogoutHandler logoutHandler = new CookieClearingLogoutHandler("JSESSIONID");
			logoutHandler.logout(req, resp, authentication);
			goPage = "redirect:/";
			break;
		}
		
		return goPage;
		
	}
}





