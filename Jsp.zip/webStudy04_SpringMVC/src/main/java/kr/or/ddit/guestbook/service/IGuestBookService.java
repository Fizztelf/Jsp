package kr.or.ddit.guestbook.service;

import java.util.List;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.vo.GuestBookVO;
import kr.or.ddit.vo.PagingVO;

public interface IGuestBookService {
	public ServiceResult createGuestBook(GuestBookVO guestBook);
	public int retrieveGuestBookCount(PagingVO<GuestBookVO> pagingVO);
	public List<GuestBookVO> retrieveGuestBookList(PagingVO<GuestBookVO> pagingVO);
	public GuestBookVO retrieveGuestBook(GuestBookVO guestBook);
	public ServiceResult modifyGuestBook(GuestBookVO guestBook);
	public ServiceResult removeGuestBook(GuestBookVO guestBook);
}
