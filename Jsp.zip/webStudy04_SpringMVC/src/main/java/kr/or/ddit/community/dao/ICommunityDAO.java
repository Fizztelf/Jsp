package kr.or.ddit.community.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import kr.or.ddit.vo.CommunityVO;
import kr.or.ddit.vo.PagingVO;

@Repository
public interface ICommunityDAO {
	public int insertCommunity(CommunityVO com);
	
	public int selectCommunityCount(PagingVO paging);
	
	public List<CommunityVO> selectCommunityList(PagingVO pagingVO);
	
	public CommunityVO selectCommunity(String writer_id);
	
	public int updateCommunity(CommunityVO com);
	
	public int deleteCommunity(String writer_id);
}
