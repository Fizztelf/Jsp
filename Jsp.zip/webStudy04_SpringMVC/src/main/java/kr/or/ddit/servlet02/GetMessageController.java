package kr.or.ddit.servlet02;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/02/getMessage.do")
public class GetMessageController{
	
	@RequestMapping(method=RequestMethod.HEAD)
	protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getOutputStream().close();
	}
	
	@GetMapping(produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String plain(@RequestParam(name="lang", required=false) String language, Locale locale) {
		if(language!=null && !language.isEmpty()){
			locale = Locale.forLanguageTag(language.toLowerCase());	
		}
		ResourceBundle bundle = ResourceBundle.getBundle("kr.or.ddit.msg.message", locale);
		String message = bundle.getString("bow");
		return message;
	}
	
	@GetMapping(produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public Map<String, Object> json(@RequestParam(name="lang", required=false) String language, Locale locale) {
		Map<String, Object> data = new HashMap<>();
		data.put("message", plain(language, locale));
		return data;
	}
	
	@GetMapping(produces="application/xml;charset=UTF-8")
	@ResponseBody
	public String xml(@RequestParam(name="lang", required=false) String language, Locale locale) {
		Map<String, Object> data = json(language, locale);
		StringBuffer xml = new StringBuffer();
		String propPtrn = "<%1$s>%2$s</%1$s>";
		xml.append("<root>");
		for( Entry<String, Object> entry  : data.entrySet() ) {
			String name = entry.getKey();
			Object value = entry.getValue();
			xml.append(String.format(propPtrn, name, value));
		}
		xml.append("</root>");
		return xml.toString();
	}	

	@GetMapping
	public String html(@RequestParam(name="lang", required=false) String language, Locale locale, Model model) {
		model.addAttribute("message", plain(language, locale));
		return "getMessage";
	}
}











