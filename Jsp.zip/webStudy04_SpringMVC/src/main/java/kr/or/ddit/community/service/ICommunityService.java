package kr.or.ddit.community.service;

import java.util.List;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.vo.CommunityVO;
import kr.or.ddit.vo.PagingVO;

public interface ICommunityService {
	public ServiceResult registerCommunity(CommunityVO com);
	
	public int retrieveCommunityCount(PagingVO pagingVO);
	
	public List<CommunityVO> retrieveCommunityList(PagingVO pagingVO);
	
	public CommunityVO retrieveCommunity(String writer_id);
	
	public ServiceResult modifyCommunity(CommunityVO com);
	
	public ServiceResult removeCommunity(CommunityVO com);
}
