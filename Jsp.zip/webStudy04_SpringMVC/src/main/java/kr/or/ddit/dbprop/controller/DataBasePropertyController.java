package kr.or.ddit.dbprop.controller;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.ddit.dbprop.service.DataBasePropertyService;
import kr.or.ddit.dbprop.service.IDataBasePropertyService;
import kr.or.ddit.vo.DataBasePropertyVO;

@Controller
public class DataBasePropertyController{
	IDataBasePropertyService service = new DataBasePropertyService();
	
	@RequestMapping(value = "/08/jdbcDesc.do", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public String data(DataBasePropertyVO paramVO , Model model) {
		List<DataBasePropertyVO> list = service.retrieveDataBaseProperty(paramVO);
		model.addAttribute("dbProps", list);
		return "jsonView";
	}
	@RequestMapping(value = "/08/jdbcDesc.do")
	public String view(DataBasePropertyVO paramVO , Model model) {
		data(paramVO, model);
		return "08/jdbcDesc";
	}
}



















