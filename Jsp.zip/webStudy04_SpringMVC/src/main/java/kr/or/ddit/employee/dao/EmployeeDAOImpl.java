package kr.or.ddit.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.db.ConnectionFactory;
import kr.or.ddit.vo.EmployeeVO;
import kr.or.ddit.vo.MemberVO;

public class EmployeeDAOImpl implements IEmployeeDAO{
	@Override
	public List<EmployeeVO> selectEmployeeHierarchy(String manager_id) {
		StringBuffer sql = new StringBuffer();   
		sql.append(" SELECT * FROM (    ");
		sql.append(" SELECT EMPLOYEE_ID, EMP_NAME, LEVEL LVL, MANAGER_ID,             ");
		sql.append("     EMAIL,    PHONE_NUMBER,    HIRE_DATE,                     ");
		sql.append("     SALARY,     COMMISSION_PCT,    RETIRE_DATE,           ");
		sql.append("     DEPARTMENT_ID,    JOB_ID,    CREATE_DATE,             ");
		sql.append("     UPDATE_DATE, CONNECT_BY_ISLEAF FOLDER                                         ");
		sql.append(" FROM EMPLOYEES                                          ");
		if(StringUtils.isBlank(manager_id)) {
			sql.append("START WITH MANAGER_ID IS NULL ");
		}else {
			sql.append("START WITH MANAGER_ID = ? ");
		}
		sql.append(" CONNECT BY PRIOR EMPLOYEE_ID = MANAGER_ID ");
		sql.append(" ) WHERE LVL = 1 ");
		
		List<EmployeeVO> list = new ArrayList<>();
		try(
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql.toString());	
		){
			System.out.println(sql);
			if(StringUtils.isNotBlank(manager_id)) {
				stmt.setString(1, manager_id);
			}
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				list.add(EmployeeVO.builder()
						.employee_id(rs.getInt("EMPLOYEE_ID"))
						.emp_name(rs.getString("EMP_NAME"))
						.email(rs.getString("EMAIL"))
						.phone_number(rs.getString("PHONE_NUMBER"))
						.hire_date(rs.getString("HIRE_DATE"))
						.salary(rs.getInt("SALARY"))
						.manager_id(rs.getInt("MANAGER_ID"))
						.commission_pct(rs.getDouble("COMMISSION_PCT"))
						.retire_date(rs.getString("RETIRE_DATE"))
						.department_id(rs.getInt("DEPARTMENT_ID"))
						.job_id(rs.getString("JOB_ID"))
						.create_date(rs.getString("CREATE_DATE"))
						.update_date(rs.getString("UPDATE_DATE"))
						.folder("0".equals(rs.getString("FOLDER")))
						.build());
			}
			return list;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}













