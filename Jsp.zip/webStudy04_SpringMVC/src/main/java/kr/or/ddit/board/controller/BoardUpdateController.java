package kr.or.ddit.board.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
@RequestMapping("/board/boardUpdate.do")
public class BoardUpdateController {
	@Inject
	private IBoardService service;
	
	@GetMapping
	public String form(
		@RequestParam("what") int bo_no
		, HttpServletRequest req
	){
		BoardVO board = service.retrieveBoard(bo_no);
		req.setAttribute("board", board);
		return "board/boardForm";
	}
	
	@PostMapping
	public String update(
			@ModelAttribute("board") BoardVO board
			, Model model
		) {
//			Map<String, List<String>> errors = new LinkedHashMap<>();
//			req.setAttribute("errors", errors);
//			CommonValidator<BoardVO> validator = new CommonValidator<>();
//			boolean valid = validator.validate(board, errors, UpdateGroup.class);
			
			String goPage = null;
			
			if(true) {
				ServiceResult result = service.modifyBoard(board);
				switch (result) {
					case OK:
						goPage =  "redirect:/board/boardView.do?what="+board.getBo_no();
						break;
					case INVALIDPASSWORD:
						model.addAttribute("message", NotyMessageVO.builder("비밀번호 오류").build());
						goPage = "board/boardForm";
						break;
					default:	
						model.addAttribute("message", NotyMessageVO.builder("서버 오류").build());
						goPage = "board/boardForm";
					break;
				}
			}else {
				goPage = "board/boardForm";
			}
			return goPage;
		}
}
