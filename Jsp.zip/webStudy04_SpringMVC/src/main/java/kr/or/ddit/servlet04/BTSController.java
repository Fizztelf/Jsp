package kr.or.ddit.servlet04;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.ddit.vo.BtsVO;

@Controller
@RequestMapping("/bts")
public class BTSController{
	@Inject
	private WebApplicationContext container;
	
	@PostConstruct
	public void init() {
		Map<String, BtsVO> btsDB = new LinkedHashMap<>();
		container.getServletContext().setAttribute("btsDB", btsDB);
		btsDB.put("B001", BtsVO.getBuilder().code("B001").name("뷔").url("bts/bui").build());
		btsDB.put("B002", BtsVO.getBuilder().code("B002").name("제이홉").url("bts/jhop").build());
		btsDB.put("B003", BtsVO.getBuilder().code("B003").name("지민").url("bts/jimin").build());
		btsDB.put("B004", BtsVO.getBuilder().code("B004").name("진").url("bts/jin").build());
		btsDB.put("B005", BtsVO.getBuilder().code("B005").name("정국").url("bts/jungkuk").build());
		btsDB.put("B006", BtsVO.getBuilder().code("B006").name("RM").url("bts/rm").build());
		btsDB.put("B007", BtsVO.getBuilder().code("B007").name("슈가").url("	bts/suga").build());
	}
	
	@GetMapping
	public String doGet(){
		return "btsForm";
	}
	
	@PostMapping
	public String doPost(@RequestParam(name="bts", required=true) String selected
			, Model model, RedirectAttributes redirectAttributes){
		
		Date now = new Date();
		model.addAttribute("now", now);
		
		Map<String, BtsVO> btsDB = (Map) container.getServletContext().getAttribute("btsDB");
		if(!btsDB.containsKey(selected)) {
			throw new RuntimeException(selected+" 멤버 없음.");
		}
		BtsVO selectedMember = btsDB.get(selected);
		redirectAttributes.addFlashAttribute("selected", selectedMember);
		String logicalView = selectedMember.getUrl();
		return logicalView;
		
	}
}













