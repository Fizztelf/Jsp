package kr.or.ddit.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Repository;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.PagingVO;

@Repository
public class BoardDAOImpl implements IBoardDAO {
	
	private SqlSessionFactory sqlSessionFactory = 
			CustomSqlSessionFactoryBuilder.getSqlSessionFactory();
	@Override
	public int insertBoard(BoardVO board, SqlSession sqlSession) {
		return sqlSession.insert("kr.or.ddit.board.dao.IBoardDAO.insertBoard", board);
	}

	@Override
	public int selectBoardCount(PagingVO<BoardVO> paging) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.selectBoardCount(paging);
		}
	}

	@Override
	public List<BoardVO> selectBoardList(PagingVO<BoardVO> paging) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.selectBoardList(paging);
		}
	}

	@Override
	public BoardVO selectBoard(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.selectBoard(bo_no);
		}
	}
	
	@Override
	public int incrementHit(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.incrementHit(bo_no);
		}
	}


	@Override
	public int updateBoard(BoardVO board) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.updateBoard(board);
		}
	}

	@Override
	public int deleteBoard(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.deleteBoard(bo_no);
		}
	}

	@Override
	public int incrementRecCnt(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.incrementRecCnt(bo_no);
		}
	}
}
