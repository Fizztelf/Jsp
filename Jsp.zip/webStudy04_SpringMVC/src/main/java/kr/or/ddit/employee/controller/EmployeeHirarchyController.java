package kr.or.ddit.employee.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.or.ddit.employee.dao.IEmployeeDAO;
import kr.or.ddit.vo.EmployeeVO;

@Controller
public class EmployeeHirarchyController{
	
	@Inject
	IEmployeeDAO dao;
	@RequestMapping("/employees/hirarchy.do")
	public String view(@RequestParam(value="base", required=false) String manager_id, Model model) {
		model.addAttribute("children", data(manager_id));
		return "employee/hirarchy";
	}
	
	@RequestMapping(value="/employees/hirarchy.do", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public List<EmployeeVO> data(@RequestParam(value="base", required=false) String manager_id) {
		List<EmployeeVO> list = dao.selectEmployeeHierarchy(manager_id);
		return list;
	}
}
















