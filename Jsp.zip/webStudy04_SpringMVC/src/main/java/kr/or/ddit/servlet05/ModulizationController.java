package kr.or.ddit.servlet05;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.ddit.enumpkg.ServiceKind;

@Controller
public class ModulizationController{
	@RequestMapping("/module.do")
	public String service(@RequestParam(name="service", required=false) ServiceKind serviceKind, Model model){
		String includePath = null;
		if(serviceKind!=null) {
			includePath = serviceKind.getMenu().getMenuPath();
			model.addAttribute("includePath", includePath);
			return "model1"+includePath;
		}else {
			return "redirect:/";
		}
	}
}












