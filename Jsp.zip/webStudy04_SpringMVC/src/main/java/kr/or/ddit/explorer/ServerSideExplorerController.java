package kr.or.ddit.explorer;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.servlet.ServletContext;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;

@Controller
@RequestMapping(value="/server/explorer.do")
public class ServerSideExplorerController{
	@Inject
	private WebApplicationContext container;
	
	@RequestMapping(produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public List<FileWrapper> data(@RequestParam(required=false, defaultValue="/") String base) {
		List<FileWrapper> list =  makeData(base, container.getServletContext());
		return list;
	}
	@RequestMapping
	public String view(@RequestParam(required=false, defaultValue="/") String base, Model model){
		model.addAttribute("children", data(base));
		return "others/explorer";
	}

	private List<FileWrapper> makeData(String base, ServletContext application) {
		String realPath = application.getRealPath(base);
		Set<String> resourcePaths = application.getResourcePaths(base);
		List<FileWrapper> list = new ArrayList<>();
		if(resourcePaths!=null) {
			TreeSet<String> treeSet = new TreeSet<>(resourcePaths);
			for(String relativePath : treeSet) {
				String fileRealPath = application.getRealPath(relativePath);
				File child = new File(fileRealPath);
				list.add(new FileWrapper(child, relativePath));
			}
			Collections.sort(list);
		}
		return list;
	}
}
















