package kr.or.ddit.vo;

import java.util.Collections;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class MemberWrapper extends User{
	
	public MemberWrapper(MemberVO realMember) {
		super(realMember.getMem_id(), realMember.getMem_pass(), 
				!"Y".equals(realMember.getMem_delete()),
				!"Y".equals(realMember.getMem_delete()),
				!"Y".equals(realMember.getMem_delete()),
				!"Y".equals(realMember.getMem_delete()),
				Collections.singleton(new SimpleGrantedAuthority(realMember.getMem_role())));
		this.realMember = realMember;
	}

	private MemberVO realMember;
	public MemberVO getRealMember() {
		return realMember;
	}
}
