package kr.or.ddit.commons.controller;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.AuthenticateServiceImpl;
import kr.or.ddit.member.service.IAuthenticateService;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
public class LoginProcessController{
	@Inject
	IAuthenticateService service;
	
	private boolean validate(String mem_id, String mem_pass) {
		return true;
	}
	
	@RequestMapping(value="/login/loginProcess.do", method=RequestMethod.POST)
	public String doPost(
			@RequestParam("mem_id") String mem_id
			, @RequestParam("mem_pass") String mem_pass
			, HttpSession session) throws ServletException, IOException {
		
		
		Object result  = service.authenticate(MemberVO.builder()
												.mem_id(mem_id)
												.mem_pass(mem_pass)
												.build());
		String goPage = null;
		if(result instanceof MemberVO) {
			MemberVO authMember = (MemberVO) result;
			session.setAttribute("authMember", authMember);
			goPage = "redirect:/";
		}else {
			String message = null;
			if(ServiceResult.NOTEXIST.equals(result)) {
				message = "아이디 오류, 그런 사람 없음.";
			}else if(ServiceResult.INVALIDPASSWORD.equals(result)){
				message = "비번 오류, 다시 입력하셈.";
				session.setAttribute("mem_id", mem_id);
			}else{
				message = "사용자가 유효하지 않슴돠.";
				session.setAttribute("mem_id", mem_id);
			}
			session.setAttribute("message", NotyMessageVO.builder(message).build());
			goPage = "redirect:/login/loginForm.do";	
		}
		return goPage;
	}
}











