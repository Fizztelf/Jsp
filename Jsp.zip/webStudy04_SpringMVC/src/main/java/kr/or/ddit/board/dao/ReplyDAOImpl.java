package kr.or.ddit.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Repository;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ReplyVO;

@Repository
public class ReplyDAOImpl implements IReplyDAO {
	
	private SqlSessionFactory sqlSessionFactory = 
			CustomSqlSessionFactoryBuilder.getSqlSessionFactory();

	@Override
	public int insertReply(ReplyVO reply) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IReplyDAO mapper = sqlSession.getMapper(IReplyDAO.class);
			return mapper.insertReply(reply);
		}
	}

	@Override
	public int selectReplyCount(PagingVO<ReplyVO> pagingVO) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IReplyDAO mapper = sqlSession.getMapper(IReplyDAO.class);
			return mapper.selectReplyCount(pagingVO);
		}
	}

	@Override
	public List<ReplyVO> selectReplyList(PagingVO<ReplyVO> pagingVO) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IReplyDAO mapper = sqlSession.getMapper(IReplyDAO.class);
			return mapper.selectReplyList(pagingVO);
		}
	}

	@Override
	public int updateReply(ReplyVO reply) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IReplyDAO mapper = sqlSession.getMapper(IReplyDAO.class);
			return mapper.updateReply(reply);
		}
	}

	@Override
	public int deleteReply(ReplyVO reply) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IReplyDAO mapper = sqlSession.getMapper(IReplyDAO.class);
			return mapper.deleteReply(reply);
		}
	}

}
