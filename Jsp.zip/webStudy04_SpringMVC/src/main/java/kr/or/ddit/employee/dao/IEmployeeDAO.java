package kr.or.ddit.employee.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import kr.or.ddit.vo.EmployeeVO;

@Repository
public interface IEmployeeDAO {
	public List<EmployeeVO> selectEmployeeHierarchy(@Param("manager_id") String manager_id);
}
