package kr.or.ddit.member.service;

import org.springframework.stereotype.Service;

@Service
public class MemberDeleteJob {
	public void deleteMember() {
		System.err.println(" 일주일의 월요일이 되어서 탈퇴 처리함");
	}
}