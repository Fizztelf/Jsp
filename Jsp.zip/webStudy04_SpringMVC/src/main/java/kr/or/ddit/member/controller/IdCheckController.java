package kr.or.ddit.member.controller;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.IMemberService;

@Controller
@RequestMapping(value="/member/idCheck.do")
public class IdCheckController{
	@Inject
	private IMemberService service;
	
	@GetMapping(produces=MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String doGet(@RequestParam("mem_id") String inputId){
		boolean canUse = false;
		try {
			service.retrieveMember(inputId);
		}catch (UsernameNotFoundException e) {
			canUse = true;
		}
		return canUse+"";
	}
	
	@PostMapping(produces=MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String doPost(@RequestParam("mem_id") String inputId) {
		boolean canUse = false;
		try {
			service.retrieveMember(inputId);
		}catch (UsernameNotFoundException e) {
			canUse = true;
		}
		return canUse?ServiceResult.OK.name():ServiceResult.FAILED.name();
	}
}











