package kr.or.ddit.servlet04;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SessionTiimerServlet{
	@RequestMapping("/sessionTimer.do")
	public String doGet(){
		return "others/sessionTimer";
	}
}

















