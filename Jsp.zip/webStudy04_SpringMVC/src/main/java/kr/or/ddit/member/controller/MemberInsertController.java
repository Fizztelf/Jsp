package kr.or.ddit.member.controller;

import java.io.IOException;
import java.util.Set;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.ServletException;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.ddit.enumpkg.PushMessageType;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.NotyMessageVO;
import kr.or.ddit.vo.PushMessageVO;
import kr.or.ddit.websocket.event.PushMessageEvent;

@Controller
@RequestMapping("/member/registMember.do")
public class MemberInsertController{
	
	@Inject
	private ApplicationEventPublisher publisher;
	
	@Inject
	private IMemberService service;
	
	@GetMapping
	public String doGet(){
		return "member/memberForm";
	}
	
	@PostMapping
	public String doPost(
			@Validated(InsertGroup.class) @ModelAttribute("member")MemberVO member, 
			 Errors errors, Model model) 
			throws ServletException, IOException {
		String goPage = null;
		boolean valid = !errors.hasErrors();
		if(valid) {
			ServiceResult result = service.registMember(member);
			switch (result) {
			case PKDUPLICATED:
				goPage = "member/memberForm";
				model.addAttribute("message", NotyMessageVO.builder("아이디 중복").build());
				break;
			case FAILED:
				goPage = "member/memberForm";
				model.addAttribute("message", NotyMessageVO.builder("서버 오류").build());
				break;
			case OK:
				PushMessageVO source = new PushMessageVO(PushMessageType.REGISTERED, member.getMem_name()+" 님 가입 성공");
				PushMessageEvent event = new PushMessageEvent(source);
				publisher.publishEvent(event);
				goPage =  "redirect:/login/loginForm.do";
				break;
			}
		}else {
			goPage = "member/memberForm";
		}
		return goPage;
	}
}