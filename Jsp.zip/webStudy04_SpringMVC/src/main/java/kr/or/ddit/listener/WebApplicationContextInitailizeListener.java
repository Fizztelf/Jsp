package kr.or.ddit.listener;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

@Component
public class WebApplicationContextInitailizeListener {
	
	private static final Logger logger = LoggerFactory.getLogger(WebApplicationContextInitailizeListener.class);
	
	@EventListener(classes=ContextRefreshedEvent.class)
	public void initailize(ContextRefreshedEvent event) {
		WebApplicationContext container = (WebApplicationContext) event.getApplicationContext();
		ServletContext application = container.getServletContext();
		application.setAttribute("cPath", application.getContextPath());
		logger.info("{} 컨텍스트 초기화, Root 컨테이너 초기화.", application.getContextPath());
	}
}
