//package kr.or.ddit.board.controller;
//
//import java.io.File;
//import java.io.IOException;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.http.MediaType;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.multipart.MultipartFile;
//
//import kr.or.ddit.explorer.FileWrapper;
//
//
//@Controller
//public class ImageUploadController {
//	@RequestMapping(value="/board/imageUpload.do", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
//	public String upload(HttpServletRequest req, HttpServletResponse resp) throws IOException {
//		FileWrapper wrapper = (FileWrapper) req;
//		MultipartFile imageFile = wrapper.getFile("upload");
//		if(imageFile==null || StringUtils.isBlank(imageFile.getOriginalFilename())) {
//			resp.sendError(400);
//			return null;
//		}
//		String saveFolderUrl = "/boardImages";
//		File saveFolder = new File(req.getServletContext().getRealPath(saveFolderUrl));
//		if(!saveFolder.exists()) {
//			saveFolder.mkdirs();
//	
//		imageFile.transferTo(saveFolder);
//		
//		req.setAttribute("fileName", imageFile.getOriginalFilename());
//		req.setAttribute("uploaded", 1);
//		String saveUrl = req.getContextPath() + saveFolderUrl+"/"+imageFile.getSavename();
//		req.setAttribute("url", saveUrl);
//		
//		return "jsonView";
//	}
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
