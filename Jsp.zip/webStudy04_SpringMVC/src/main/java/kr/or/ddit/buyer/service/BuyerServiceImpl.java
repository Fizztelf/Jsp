package kr.or.ddit.buyer.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.WebApplicationContext;

import kr.or.ddit.CustomException;
import kr.or.ddit.buyer.dao.IBuyerDAO;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.vo.BuyerVO;
import kr.or.ddit.vo.PagingVO;

@Repository
public class BuyerServiceImpl implements IBuyerService{
	private static final Logger LOGGER = LoggerFactory.getLogger(BuyerServiceImpl.class);
	
	@Inject
	private WebApplicationContext container;
	@Inject
	private IBuyerDAO buyerDAO;
	
	@Value("#{appInfo.buyerImages}")
	private String imagePath;
	
	private File saveFolder;
	@PostConstruct
	public void init() throws IOException {
		saveFolder = container.getResource(imagePath).getFile();
		if(!saveFolder.exists()) saveFolder.mkdirs();
		LOGGER.info("{}", saveFolder.getAbsolutePath());
	}
	
	@Override
	public int retrieveBuyerCount(PagingVO<BuyerVO> pagingVO) {
		return buyerDAO.selectBuyerCount(pagingVO);
	}

	@Override
	public List<BuyerVO> retrieveBuyerList(PagingVO<BuyerVO> pagingVO) {
		return buyerDAO.selectBuyerList(pagingVO);
	}

	@Override
	public BuyerVO retrieveBuyer(String buyer_id) {
		BuyerVO buyer = buyerDAO.selectBuyer(buyer_id);
		if(buyer==null) throw new CustomException("없음.");
		return buyer;
	}

	@Override
	public ServiceResult createBuyer(BuyerVO buyer) throws IOException {
		int rowcnt = buyerDAO.insertBuyer(buyer);
		ServiceResult result = ServiceResult.OK;
		if(rowcnt<= 0) result = ServiceResult.FAILED;
		else {
			buyer.saveTo(saveFolder);
		}
		return result;
	}

	@Override
	public ServiceResult modifyBuyer(BuyerVO buyer) throws IOException {
		retrieveBuyer(buyer.getBuyer_id());
		int rowcnt = buyerDAO.updateBuyer(buyer);
		ServiceResult result = ServiceResult.OK;
		if(rowcnt <= 0) result = ServiceResult.FAILED;
		else {
			buyer.saveTo(saveFolder);
		}
		return result;
	}

}
