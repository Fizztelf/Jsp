package kr.or.ddit.buyer.controller;

import java.io.IOException;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import kr.or.ddit.buyer.service.IBuyerService;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.vo.BuyerVO;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
@RequestMapping("/buyer/buyerInsert.do")
@SessionAttributes("buyer")
public class BuyerInsertController{
	
	@Inject
    private IBuyerService service;
	
	@ModelAttribute("currentAction")
	public String addAttribute() {
		return "/buyer/buyerInsert.do";
	}
	
	@ModelAttribute("buyer")
	public BuyerVO emptyBuyer() {
		BuyerVO buyer = new BuyerVO();
		return buyer;
	}

	@GetMapping
	public String form(@ModelAttribute("buyer") BuyerVO buyer){
		return "buyer/buyerForm";
	}
	
	@PostMapping
	public String insert(
		@Validated(InsertGroup.class) @ModelAttribute("buyer") BuyerVO buyer
		, Errors errors
		, Model model
		, SessionStatus status
	) throws IOException {
		String goPage = null;
		if (!errors.hasErrors()) {
//		2. 로직 선택 service.createbuyer(buyer)
			ServiceResult result = service.createBuyer(buyer);
//		3. 로직의 실행 결과에 따른 분기 페이지 선택
			switch (result) {
			case OK:
				goPage = "redirect:/buyer/buyerView.do?what="+buyer.getBuyer_id();
				status.setComplete();
				break;
			default: // FAIL
				model.addAttribute("message", NotyMessageVO.builder("서버 오류").build());
				goPage = "buyer/buyerForm";
				break;
			}
		} else {
			goPage = "buyer/buyerForm";
		}
//		4. 모델 데이터 공유
		return goPage;
	}
}