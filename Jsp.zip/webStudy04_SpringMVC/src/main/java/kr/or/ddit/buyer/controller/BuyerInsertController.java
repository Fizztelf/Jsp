package kr.or.ddit.buyer.controller;

import java.io.File;
import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.ddit.buyer.service.IBuyerService;
import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.vo.BuyerVO;
import kr.or.ddit.vo.NotyMessageVO;

@Controller
@RequestMapping("/buyer/buyerInsert.do")
public class BuyerInsertController{
	
	@Inject
    private IBuyerService service;
	
	public void addAttribute(Model model) {
		model.addAttribute("currentAction", "/buyer/buyerInsert.do");
	}
    
	@GetMapping
	public String form(Model model){
		addAttribute(model);
		return "buyer/buyerForm";
	}
	
	@PostMapping
	public String insert( @Validated(InsertGroup.class)
			@ModelAttribute("buyer") BuyerVO buyer, Errors errors, Model model, HttpServletRequest req
			) throws IOException {
		addAttribute(model);
		
//		Map<String, List<String>> errors = new LinkedHashMap<>();
//		req.setAttribute("errors", errors);
//		CommonValidator<BuyerVO> validator = new CommonValidator<>();
//		boolean valid = validator.validate(buyer, errors, InsertGroup.class);
		
		String goPage = null;
		boolean valid = !errors.hasErrors();
		String saveFolderUrl = "/buyerImages";
		File saveFolder = new File(req.getServletContext().getRealPath(saveFolderUrl));
		if(!saveFolder.exists()) {
			saveFolder.mkdirs();
		}
		
		if (valid) {
//		2. 로직 선택 service.createbuyer(buyer)
			ServiceResult result = service.createBuyer(buyer);
//		3. 로직의 실행 결과에 따른 분기 페이지 선택
			switch (result) {
			case OK:
				buyer.saveTo(saveFolder);
				goPage = "redirect:/buyer/buyerView.do?what="+buyer.getBuyer_id();
				break;
			default: // FAIL
				model.addAttribute("message", NotyMessageVO.builder("서버 오류").build());
				goPage = "buyer/buyerForm";
				break;
			}
		} else {
			goPage = "buyer/buyerForm";
		}
//		4. 모델 데이터 공유
		return goPage;
	}
}