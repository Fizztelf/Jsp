--계층형 답글 구조를 갖고 있는 방명록 구현.
--참고 : https://impresident.tistory.com/guestbook

--방명록 기본 CRUD (RESTful URI 방식으로 구현, 데이터는 json 형태로 표현함.)
--전체 방명록 조회 : /guestBook, GET (페이징 처리)
--방명록 작성 : /guestBook, POST
--방명록 수정 : /guestBook, PUT
--방명록 삭제 : /guestBook, DELETE
--방명록 답글 : /guestBook/상위방명록번호, /POST
--
--모든 기능은 하나의 view layer 내에서 비동기로 처리됨.

CREATE TABLE GUESTBOOK(
	GB_NO NUMBER(6), -- 방명록 번호
	GB_WRITER VARCHAR2(30) NOT NULL, -- 방명록 작성자
	GB_PASS VARCHAR2(300) NOT NULL, -- 인증용 비밀번호
	GB_IP VARCHAR2(40) NOT NULL, -- 작성자 IP 
	GB_CONTENT VARCHAR2(200), -- 방명글
	GB_PARENT NUMBER(6), -- 상위방명록번호
	GB_DEPTH NUMBER(1) DEFAULT 1, -- 방명록답글의 깊이(루트글:1 부터 답글이 추가될시 깊이가 증가함. 답글 깊이 제한에 사용.)
   	 GB_DATE DATE DEFAULT SYSDATE, -- 작성일
	GB_PROFILE BLOB, -- 작성자 프로필 이미지
	GB_SECRET CHAR(1),
	CONSTRAINT PK_GUESTBOOK PRIMARY KEY(GB_NO)
);

ALTER TABLE GUESTBOOK 
ADD CONSTRAINTS FK_GB_GB 
    FOREIGN KEY  (GB_PARENT) REFERENCES GUESTBOOK(GB_NO);