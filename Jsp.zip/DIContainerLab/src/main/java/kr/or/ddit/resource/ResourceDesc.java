package kr.or.ddit.resource;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

/**
 * 리소스(File, Resource) 
 * 1. 웹 리소스 : UrlResource, ServletContextResource
 * 2. 클래스패스 리소스 : ClasspathResource
 * 3. 파일시스템 리소스 : FileSystemResource
 */
public class ResourceDesc {
	public static void main(String[] args) throws IOException, URISyntaxException {
		Resource file1 = new ClassPathResource("kr/or/ddit/sample/conf/Container-Desc.xml");
		ApplicationContext container =
				new GenericXmlApplicationContext(file1);
		
		file1 = container.getResource("classpath:kr/or/ddit/sample/conf/Sample-Context.xml");
		System.out.println(file1.getClass());
		
		
//		Resource file2 = new UrlResource(new URI("https://www.google.com/tia/tia.png"));
		Resource file2 = container.getResource("https://www.google.com/tia/tia.png");
		System.out.println(file2.getClass());
		
//		Resource file3 = new FileSystemResource("d:/saveFiles");
		Resource file3 = container.getResource("file:d:/saveFiles");
		System.out.println(file3.getClass());
		
		
		
		
	}
}
