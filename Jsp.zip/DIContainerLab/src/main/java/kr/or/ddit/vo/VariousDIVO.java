package kr.or.ddit.vo;

import java.io.File;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VariousDIVO {
	private String str;
	private char c;
	private int num;
	private boolean bool;
	private double dbl;
	
	private File file;
}
