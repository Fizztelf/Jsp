package kr.or.ddit.sample.service;

public interface ISampleService {
	public StringBuffer retrieveDatabyPK(String pk);
}
