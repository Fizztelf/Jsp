package kr.or.ddit.sample.view;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import kr.or.ddit.sample.service.ISampleService;

public class ContainerDescTestView {
	public static void main(String[] args) {
		
		ConfigurableApplicationContext container = new GenericXmlApplicationContext("classpath:kr/or/ddit/sample/conf/Container-Desc.xml");
//		ISampleService service1 = container.getBean(ISampleService.class);	
//		ISampleService service2 = container.getBean(ISampleService.class);
//		ISampleService service3 = container.getBean(ISampleService.class);
//		System.out.println(service1 == service2);
//		System.out.println(service1);
//		System.out.println(service2);
//		System.out.println(service3);
		
//		System.out.println(service.retrieveDatabyPK("a001"));
		
		container.close();
	}
}
