package kr.or.ddit.sample.dao;

public class SampleDAO_Mysql implements ISampleDAO {

	public SampleDAO_Mysql() {
		super();
		System.out.println(getClass().getSimpleName()+" 기본 생성자로 생성");
	}
	 
	
	@Override
	public String selectDataByPK(String pk) {
		return String.format(" Mysql DB 에서 pk[%s]로 조회한 레코드",pk);
	}

}
