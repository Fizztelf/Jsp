package kr.or.ddit.various;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.or.ddit.vo.VariousDIVO;

public class VariousDITestView {
	public static void main(String[] args) {
		
		ConfigurableApplicationContext container
		= new ClassPathXmlApplicationContext("classpath:kr/or/ddit/various/Various-Context.xml");
		
		VariousDIVO various = container.getBean("vo2", VariousDIVO.class);
		System.out.println(various);
	}
}
