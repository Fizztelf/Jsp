package kr.or.ddit.sample.dao;

public class SampleDAOFactory {
	public static ISampleDAO getSampleDAO() {
		return new SampleDAOImpl();
	}
}
