package kr.or.ddit.sample.service;

import kr.or.ddit.sample.dao.ISampleDAO;
import kr.or.ddit.sample.dao.SampleDAOFactory;
import kr.or.ddit.sample.dao.SampleDAOImpl;
import kr.or.ddit.sample.dao.SampleDAO_Mysql;

public class SampleServiceImpl implements ISampleService {

	//1. 직접 instance 생성(결합력 최상)
//	private ISampleDAO dao = new SampleDAO_Mysql();
	
	//2. Factory Object Pattern 
//	private ISampleDAO dao = SampleDAOFactory.getSampleDAO();
	
	//3. Strategy Pattern (DI) - 전략주입자 필요
	
	//4. DI Container 활용(어플 밖의 객체 주입)
	private ISampleDAO dao;
	
	public SampleServiceImpl() {
		System.out.println(getClass().getSimpleName()+" 기본 생성자로 생성");
	}
	
	
	public SampleServiceImpl(ISampleDAO dao) {
		this.dao = dao;
		System.out.println(getClass().getSimpleName()+" 인자가 있는 생성자로 생성");
	}

	public void setDao(ISampleDAO dao) {
		this.dao = dao;
		System.out.println("Setter Injectrion 으로 주입");
	}
	
	public void init() {
		System.out.println(getClass().getSimpleName()+"초기화" + dao.toString());
	}
	
	public void destroy() {
		System.out.println(getClass().getSimpleName()+"소멸");
	}
			
	//4. DI Container 활용(어플 밖의 전략 주입자 사용)
	
	@Override
	public StringBuffer retrieveDatabyPK(String pk) {
		String raw = dao.selectDataByPK(pk);
		StringBuffer model = new StringBuffer(raw);
		model.append(" logic 으로 가공한 컨텐츠 ");
		return model;
	}

}
