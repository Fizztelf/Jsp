package kr.or.ddit.sample.dao;

public interface ISampleDAO {
	public String selectDataByPK(String pk);
}
