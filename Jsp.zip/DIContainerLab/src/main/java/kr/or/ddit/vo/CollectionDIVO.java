package kr.or.ddit.vo;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor // 생성자, 기본생성자는 지워짐... xml에서는 오류가 남
@Data
@NoArgsConstructor
public class CollectionDIVO {
	
	private List<String> list;
	private Set<?> set;
	private Map<?, ?> map;
	private Properties props;
	
	
	private String[] array;
	
	public void init() {
		System.out.println(getClass().getSimpleName()+" 초기화");
		System.out.println(this);
	}
	
	public void destroy() {
		System.out.println(getClass().getSimpleName()+" 소멸");
//		System.out.println(this);
	}
}
