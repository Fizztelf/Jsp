package kr.or.ddit.sample.dao;

public class SampleDAOImpl implements ISampleDAO {

	public SampleDAOImpl() {
		super();
		System.out.println(getClass().getSimpleName()+" 기본 생성자로 생성");
	}
	@Override
	public String selectDataByPK(String pk) {
		return String.format("오라클 DB 에서 pk[%s]로 조회한 레코드",pk);
	}

}
