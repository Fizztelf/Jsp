package kr.or.ddit.various;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import kr.or.ddit.vo.CollectionDIVO;

public class CollectionDITestView {
	public static void main(String[] args) {
		try(
		ConfigurableApplicationContext container
		= new GenericXmlApplicationContext("classpath:kr/or/ddit/various/Collection-Context.xml");
		){
			
			CollectionDIVO vo1 = container.getBean("vo1",CollectionDIVO.class);
			CollectionDIVO vo2 = container.getBean("vo2",CollectionDIVO.class);
			CollectionDIVO vo3 = container.getBean("vo3",CollectionDIVO.class);
		}
		
		
	}
}
