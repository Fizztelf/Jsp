package kr.or.ddit.controller;

import java.io.IOException;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.ddit.service.SampleService;
import kr.or.ddit.vo.SampleVO;

@Controller
@RequestMapping("/sample/upload.do")
public class FileUploadController {
	@Resource(type=SampleService.class)		// 조건을 명시해줘야함
	private SampleService service;
	@GetMapping
	public String form() {
		return "sample/form";
	}
	
	@PostMapping
	public String process(@ModelAttribute("sample") SampleVO vo
			, Model model, RedirectAttributes redirectAttributes) throws IllegalStateException, IOException { // command object
		String content = service.upload(vo);
		if("success".equals(content)) {
			redirectAttributes.addFlashAttribute("content", content);
			return "redirect:/sample.do";
		} else {
			model.addAttribute("content", content);
			return "sample/form";
		}
	
	}
}
