package kr.or.ddit.vo;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

public class SampleVO {
	private String str;
	private MultipartFile file1;
	private String savename;
	public void setFile1(MultipartFile file1) {
		if(file1 == null || file1.isEmpty()) {
			return;
		}
		this.file1 = file1;
		savename = UUID.randomUUID().toString();
	}
	
	public void saveTo(File saveFolder) throws IllegalStateException, IOException {
		if(file1!=null) {
			file1.transferTo(new File(saveFolder, savename));
		}
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public String getSavename() {
		return savename;
	}

	public void setSavename(String savename) {
		this.savename = savename;
	}

	public MultipartFile getFile1() {
		return file1;
	}
	
	
}
