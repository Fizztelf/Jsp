package kr.or.ddit.controller;

import javax.inject.Inject;
import java.util.Locale;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.or.ddit.service.SampleService;

@Controller
public class SampleController {
	@Inject
	private SampleService service;
	
	@RequestMapping("/sample.do")
	public ModelAndView sample(@RequestParam(required=false, defaultValue="1")int number,Locale locale) {
		String content = service.retireveModel();
		ModelAndView mav = new ModelAndView();
		mav.addObject("content", content+number);
		mav.setViewName("sample/view");
//		return "sample/view";
		return mav;
	}
	
//	@GetMapping("/sample.do")
//	public String sample(Local locale, Model model) {
//		String content = service.retireveModel();
//		model.addAttribute("content", content);
//		return "sample/view";
//	}
}
