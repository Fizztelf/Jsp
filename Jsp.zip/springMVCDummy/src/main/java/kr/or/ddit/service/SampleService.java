package kr.or.ddit.service;

import java.io.File;
import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import kr.or.ddit.vo.SampleVO;

@Service
public class SampleService {
	@Inject
	private WebApplicationContext container;
	
	@Value("#{appInfo['boardImages']}")
	private String boardImagesProp; // url 만 갖고 있음
	
	@PostConstruct // 생성자 이후 호출??
	public void init() throws IOException {  // 이 예외는 init이 호출해주는 애가 즉, container가 가져감. 이걸 또 톰캣한테 줌
		if(!boardImages.exists()) {
			boardImages.mkdirs();
		}
		System.out.println(boardImages.getAbsolutePath());
	}
	
	@Value("#{appInfo['boardImages']}")
	private File boardImages;
	
	public String retireveModel() {
		return "모델 데이터";
	}

	public String upload(SampleVO vo) throws IllegalStateException, IOException { // 예외는 컨트롤러가 가져감
		System.out.println(vo.getStr());
		System.out.println(vo.getSavename());
		vo.saveTo(boardImages);
		return "success";
	}
}
