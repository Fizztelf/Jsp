package kr.or.ddit.callmethod;

public class MethodInvokeTest {
	public static void main(String[] args) {
//		String arg = "original data";
//		callByValue(arg);
//		System.out.println(arg);
		
		StringBuffer buffer = new StringBuffer("original data ");
		callByReference(buffer);
		System.out.println(buffer);
	}
	
	private static void callByValue(String arg) {
		arg = arg + " processed";
		System.out.println(arg);
	}
	
	private static void callByReference(StringBuffer buffer) {
		buffer.append(" processed ");
	}
}
