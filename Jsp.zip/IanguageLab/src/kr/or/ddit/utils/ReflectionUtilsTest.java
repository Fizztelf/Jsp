package kr.or.ddit.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Map.Entry;

import kr.or.ddit.annotation.stereotype.MarkerAnnotation;
import kr.or.ddit.annotation.test.TestWithAnnotation;

public class ReflectionUtilsTest {
	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
		Map<Class<?>,Annotation> classes = ReflectionUtils.getClassesWithAnnotationAtBasePackages(MarkerAnnotation.class, "kr.or.ddit");
		for(Entry<Class<?>, Annotation> entry : classes.entrySet()) {
			Class<?> handlerType = entry.getKey();
			Annotation annotation = entry.getValue();
			System.out.printf("%s : %s \n", handlerType, annotation);
		}
		Map<Method, Annotation> methods = ReflectionUtils.getMethodsWithAnnotationAtClass(TestWithAnnotation.class, MarkerAnnotation.class, String.class);
		for(Entry<Method, Annotation> entry : methods.entrySet()) {
			System.out.println(entry);
			Method method = entry.getKey();
			MarkerAnnotation annotation = (MarkerAnnotation)entry.getValue();
			String uri = annotation.value();
			Object obj = TestWithAnnotation.class.newInstance();
			String viewName = (String) method.invoke(obj);
			System.out.printf("%s : %s \n", uri, viewName);
			
		}
	}
}
