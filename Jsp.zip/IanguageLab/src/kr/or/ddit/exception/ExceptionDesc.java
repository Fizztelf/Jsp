package kr.or.ddit.exception;

import java.io.IOException;

/**
 * 밑 두개의 공통점 : Throwable
 * - Error : 개발자가 처리하지 않고 VM 이 제어권을 가져가는 비정상
 * - Exception : 처리할 수 있는 비정상
 *     1) checked exception(이 예외의 상위는 Exception)
 *        : 예외 발생 가능 코드에 대해 적극적 예외 처리 필요
 *     2) unchecked exception(이 예외의 상위는 Exception -> RuntimeException)
 *        : 직접 처리하지 않더라도 호출 구조에 따라 throw가 되는 예외, 최종적으로 VM 이 제어권 획득
 *
 * throws(수동적 처리, 호출자에게 제어권 전달), try~catch~finally(해당 메소드 내에서 적극 처리)
 * 
 * 예외발생
 * => throw new 예외객체 
 * 
 */
public class ExceptionDesc {
	public static void main(String[] args) throws IOException{
		try {
			method1();
		} catch (RuntimeException e) {
			System.err.println(e.getMessage());
			throw e;
		} catch(Exception e) {
			System.err.println(e.getMessage());
			throw new RuntimeException(e);
			
		}
	}
	
	private static void method1() throws IOException{
		if(1==1) {
//			throw new IOException("강제 발생 예외");
//			throw new IllegalArgumentException("강제 발생 예외");
			throw new CustomException("강제 발생 예외");
		}
	}
}
