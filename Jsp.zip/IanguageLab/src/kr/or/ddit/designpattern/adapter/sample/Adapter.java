package kr.or.ddit.designpattern.adapter.sample;

public class Adapter implements Target {
	
	private Adaptee adaptee;
	
//	wrapper , int 값만 존재하는 리터럴 / Integer 힙메모리에저장
	public Adapter(Adaptee adaptee) {	
		this.adaptee = adaptee;
	}

	@Override
	public void request() {
		adaptee.specificRequest();
	}

}
