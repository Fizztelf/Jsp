package kr.or.ddit.designpattern.adapter.sample;

public interface Target {
	public void request();
}
