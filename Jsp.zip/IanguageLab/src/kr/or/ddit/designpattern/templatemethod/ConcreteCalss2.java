package kr.or.ddit.designpattern.templatemethod;

public class ConcreteCalss2 extends TemplateClass {

	@Override
	protected void hookmethod() {
		System.out.println("구체적인 작업 내용, " +getClass().getSimpleName());
	}

}
