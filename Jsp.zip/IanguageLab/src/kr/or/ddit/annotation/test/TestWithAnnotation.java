package kr.or.ddit.annotation.test;

import kr.or.ddit.annotation.stereotype.MarkerAnnotation;

@MarkerAnnotation(value="key", option=10)
public class TestWithAnnotation {
	private int option;

	public int getOption() {
		return option;
	}

	public void setOption(int option) {
		this.option = option;
	}

	@MarkerAnnotation("/test.do")
	public String test() {
		return "test login";
	}
	@Override
	public String toString() {
		return "TestWithAnnotation [option=" + option + "]";
	}
	
}
