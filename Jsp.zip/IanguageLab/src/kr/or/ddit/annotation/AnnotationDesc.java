package kr.or.ddit.annotation;

import java.beans.PropertyDescriptor;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import kr.or.ddit.annotation.stereotype.MarkerAnnotation;

/**
 * annotation : 시스템과 사람에게 일정 정보를 제공하기 위한 메타 데이터 표현 방식
 * 
 * 1) marker annotation
 * 2) single value annotation : value 속성으로 설정하는 경우, single value 속성명 생략 가능
 * 3) multi value annotation : 모든 속성 명을 기술.
 * 
 * custom annotation : @interface 키워드로 정의, 필수 정책(@Target, @Retention)
 */
public class AnnotationDesc {
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		String basePackage = "kr.or.ddit.annotation.test";
		String baseFolderPath = basePackage.replaceAll("\\.", "/");
		String realPath = AnnotationDesc.class.getResource("/"+baseFolderPath).getFile();
		File baseFolder = new File(realPath);
		File[] children = baseFolder.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".class");
			}
		});
		Map<String, Object> withAnnotation = new HashMap<>();
		Map<String, Object> withOutAnnotation =  new HashMap<>();
		
		for(File child : children) {
			String name = child.getName();
			int lastIdx = name.lastIndexOf(".class");
			String simpleName = name.substring(0, lastIdx);
			String qualified = basePackage+"."+simpleName;
			Class<?> type = Class.forName(qualified);
			MarkerAnnotation annotation = type.getAnnotation(MarkerAnnotation.class);
			Object instance = type.newInstance();
			if(annotation == null) {
				withOutAnnotation.put(simpleName, instance);
			} else {
				String value = annotation.value();
				int option = annotation.option();
//				PropertyDescriptor pd = new PropertyDescriptor("option", type);
//				pd.getWriteMethod().invoke(instance, option);
				withAnnotation.put(value, instance);
			}
		}
		System.out.println(withAnnotation);
		System.out.println(withOutAnnotation);
	}
}
