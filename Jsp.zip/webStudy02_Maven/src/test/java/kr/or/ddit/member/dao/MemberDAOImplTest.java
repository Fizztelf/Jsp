package kr.or.ddit.member.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class MemberDAOImplTest {

	@Test
	public void testGetInstance() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectMember() {
		fail("Not yet implemented");
	}

	@Test
	public void testInsertMember() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectMemberList() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateMember() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteMember() {
		fail("Not yet implemented");
	}

}
