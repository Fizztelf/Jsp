package kr.or.ddit.servlet03.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import kr.or.ddit.db.ConnectionFactory;
import kr.or.ddit.vo.MemberVO;
import kr.or.ddit.vo.MemberVO.MemberVOBuilder;

public class LoginTestDAO {
	public MemberVO selecteMember(String mem_id, String mem_pass) {
		
		StringBuffer sql = new StringBuffer();
		sql.append( " SELECT MEM_ID, MEM_NAME, MEM_REGNO1, MEM_REGNO2 " );
		sql.append( " FROM MEMBER " );
		sql.append( " WHERE MEM_ID  = ? AND MEM_PASS = ? " );
		
		MemberVO member = null;
		
		try (
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql.toString());
		){

			stmt.setString(1, mem_id);
			stmt.setString(2, mem_pass);
			
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				
				member = new MemberVO();
				member.setMem_id(rs.getString("MEM_ID") );
				member.setMem_name(rs.getString("MEM_NAME") );
				member.setMem_regno1(rs.getString("MEM_REGNO1") );
				member.setMem_regno2(rs.getString("MEM_REGNO2") );
			}
			
			return member;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
