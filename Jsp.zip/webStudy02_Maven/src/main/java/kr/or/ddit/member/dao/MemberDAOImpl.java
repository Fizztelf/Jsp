package kr.or.ddit.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.db.ConnectionFactory;
import kr.or.ddit.vo.MemberVO;

public class MemberDAOImpl implements IMemberDAO {
	private static IMemberDAO dao;
	
	public static IMemberDAO getInstance() {
		if(dao == null) {
			dao = new MemberDAOImpl();
		}
		return dao;
	}
	
	@Override
	public MemberVO selectMember(String mem_id) {
		StringBuffer sql = new StringBuffer();
		sql.append( " SELECT MEM_ID, " );
		sql.append( "  MEM_PASS, MEM_NAME, MEM_REGNO1, MEM_REGNO2,  " );
		sql.append( " MEM_BIR, MEM_ZIP, MEM_ADD1, MEM_ADD2, MEM_HOMETEL,  " );
		sql.append( " MEM_COMTEL, MEM_HP, MEM_MAIL, MEM_JOB, MEM_LIKE, " );
		sql.append( " MEM_MEMORIAL, MEM_MEMORIALDAY," );
		sql.append( " MEM_MILEAGE, MEM_DELETE  " );
		sql.append( " FROM MEMBER " );
		sql.append( " WHERE MEM_ID  = ? 				" );
		
		MemberVO member = null;
		
		try (
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql.toString());
		){

			stmt.setString(1, mem_id);
			
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				member = MemberVO.builder()
									.mem_id(rs.getString("MEM_ID"))
									.mem_pass(rs.getString("MEM_PASS"))
									.mem_name(rs.getString("MEM_NAME"))
									.mem_regno1(rs.getString("MEM_REGNO1"))
									.mem_regno2(rs.getString("MEM_REGNO2"))
									.mem_bir(rs.getString("MEM_BIR"))
									.mem_zip(rs.getString("MEM_ZIP"))
									.mem_add1(rs.getString("MEM_ADD1"))
									.mem_add2(rs.getString("MEM_ADD2"))
									.mem_hometel(rs.getString("MEM_HOMETEL"))
									.mem_comtel(rs.getString("MEM_COMTEL"))
									.mem_hp(rs.getString("MEM_HP"))
									.mem_mail(rs.getString("MEM_MAIL"))
									.mem_job(rs.getString("MEM_JOB"))
									.mem_like(rs.getString("MEM_LIKE"))
									.mem_memorial(rs.getString("MEM_MEMORIAL"))
									.mem_memorialday(rs.getString("MEM_MEMORIALDAY"))
									.mem_mileage(rs.getInt("MEM_MILEAGE"))
									.mem_delete(rs.getString("MEM_DELETE"))
									.build();
			}
			return member;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public int insertMember(MemberVO member) {
		StringBuffer sql = new StringBuffer();                             
		sql.append(" INSERT INTO MEMBER (										");
		sql.append(" 		MEM_ID,    MEM_PASS,    MEM_NAME,					");
		sql.append(" 	    MEM_REGNO1,    MEM_REGNO2,    MEM_BIR,              ");
		sql.append(" 	    MEM_ZIP,    MEM_ADD1,    MEM_ADD2,                  ");
		sql.append(" 	    MEM_HOMETEL,    MEM_COMTEL,    MEM_HP,              ");
		sql.append(" 	    MEM_MAIL,    MEM_JOB,    MEM_LIKE,                  ");
		sql.append(" 	    MEM_MEMORIAL,    MEM_MEMORIALDAY,    MEM_MILEAGE   ");
		sql.append(" 	         ");
		sql.append(" 	) VALUES (                                              ");
		sql.append(" 			?,    ?,    ?                                   ");
		sql.append(" 		   ,?,    ?,    ?        							  ");
		sql.append(" 		   ,?,    ?,    ?                                   ");
		sql.append(" 		   ,?,    ?,    ?                                   ");
		sql.append(" 		   ,?,    ?,    ?                                   ");
		sql.append(" 		   ,?,    ?,    3000            ");
		sql.append(" 	)                                                       ");
		try(
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql.toString());	
		){
			int i = 1;
			stmt.setString(i++, member.getMem_id());
			stmt.setString(i++, member.getMem_pass());
			stmt.setString(i++, member.getMem_name());
			stmt.setString(i++, member.getMem_regno1());
			stmt.setString(i++, member.getMem_regno2());
			stmt.setString(i++, member.getMem_bir());
			stmt.setString(i++, member.getMem_zip());
			stmt.setString(i++, member.getMem_add1());
			stmt.setString(i++, member.getMem_add2());
			stmt.setString(i++, member.getMem_hometel());
			stmt.setString(i++, member.getMem_comtel());
			stmt.setString(i++, member.getMem_hp());
			stmt.setString(i++, member.getMem_mail());
			stmt.setString(i++, member.getMem_job());
			stmt.setString(i++, member.getMem_like());
			stmt.setString(i++, member.getMem_memorial());
			stmt.setString(i++, member.getMem_memorialday());
//			stmt.setInt(i++, member.getMem_mileage());
//			stmt.setString(i++, member.getMem_delete());
			
			return stmt.executeUpdate();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public List<MemberVO> selectMemberList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateMember(MemberVO member) {
		StringBuffer sql = new StringBuffer();                             
		sql.append(" 		 UPDATE MEMBER  			     			");
		sql.append(" 			SET	MEM_ID = ?,							");
		sql.append(" 				MEM_PASS = ? ,						");
		sql.append(" 				MEM_NAME = ?,						");
		sql.append(" 				MEM_REGNO1 =?,  					");
		sql.append(" 				MEM_REGNO2 =?,						");
		sql.append(" 				MEM_BIR = ?,						");
		sql.append(" 				MEM_ZIP = ?,						");
		sql.append(" 	    		MEM_ADD1 = ?,   	                ");
		sql.append(" 				MEM_ADD2 = ?,						");
		sql.append(" 	   			MEM_HOMETEL =? ,                    ");
		sql.append("        		MEM_COMTEL = ? ,                    ");
		sql.append("        		MEM_HP = ?,                         ");
		sql.append(" 	    		MEM_MAIL = ?,                       ");
		sql.append("        		MEM_JOB = ?,                        ");
		sql.append("       		    MEM_LIKE = ?,                       ");
		sql.append(" 	    		MEM_MEMORIAL =?,                    ");
		sql.append("        		MEM_MEMORIALDAY =? ,                ");
		sql.append("        		MEM_MILEAGE = 3000                  ");
		sql.append("          WHERE MEM_ID = ?                     ");
		try(
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql.toString());	
		){
			int i = 1;
			stmt.setString(i++, member.getMem_id());
			stmt.setString(i++, member.getMem_pass());
			stmt.setString(i++, member.getMem_name());
			stmt.setString(i++, member.getMem_regno1());
			stmt.setString(i++, member.getMem_regno2());
			stmt.setString(i++, member.getMem_bir());
			stmt.setString(i++, member.getMem_zip());
			stmt.setString(i++, member.getMem_add1());
			stmt.setString(i++, member.getMem_add2());
			stmt.setString(i++, member.getMem_hometel());
			stmt.setString(i++, member.getMem_comtel());
			stmt.setString(i++, member.getMem_hp());
			stmt.setString(i++, member.getMem_mail());
			stmt.setString(i++, member.getMem_job());
			stmt.setString(i++, member.getMem_like());
			stmt.setString(i++, member.getMem_memorial());
			stmt.setString(i++, member.getMem_memorialday());
			stmt.setInt(i++, member.getMem_mileage());
			stmt.setString(i++, member.getMem_delete());
			
			return stmt.executeUpdate();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public int deleteMember(String mem_id) {
		StringBuffer sql = new StringBuffer();                             
		sql.append( " UPDATE MEMBER " );
		sql.append( " SET MEM_DELETE = 'Y' " );
		sql.append( " WHERE MEM_ID = ? " );
		
		try(
			Connection conn = ConnectionFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql.toString());	
		){
			stmt.setString(1, mem_id);
			return stmt.executeUpdate();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
	}
}
