package kr.or.ddit.servlet01;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.ddit.utils.CookieUtils;
import kr.or.ddit.utils.CookieUtils.TextType;

/**
 * 2020년 10월 20일
 * 이미지 스트리밍 서비스
 * 클라이언트 입장에서 서버에 있는 이미지를 가져오는 것 doGet
 * 서버에 있는 이미지를 가져와서 클라이언트에게 전해주어야 함. 중개가 필요
 * 	1. 요청을 받음
 * 	2. 파일을 읽어와야 함
 * 
 * 클라이언트가 보내는 정보는 믿지 말고 확인작업 필요
 * 응답 데이터를 내보낼 때도, 정상 처리가 되는 경우와 비정상인 경우를 구분해서 적절하게 상태 코드를 내보내야 한다.
 */
@WebServlet("/imageView.do")
//만약 맵핑하는 과정에서 /를 제외하면 상대경로로 바뀌고 결과적으로 톰캣에서는 주소를 식별할 수 없어서 터짐 (서버사이드에서는 반드시 절대경로를 사용할것)
public class ImageStreamingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String COOKIENAME = "imageCookie";
	File folder; //전역 변수 선언 후 한번만 호출하면 되는 init 오버라이드
	@Override
		public void init(ServletConfig config) throws ServletException {
			//반드시 있어야 함
			super.init(config);
			String contentFolder = getServletContext().getInitParameter("contentFolder");
//			String contentFolder = config.getInitParameter("contentFolder");
			folder = new File(contentFolder);
		}
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	try(
			InputStream is = req.getInputStream();
		){
    		ObjectMapper mapper = new ObjectMapper();
    		String[] array = mapper.readValue(is, String[].class);
    		String jsonValue = mapper.writeValueAsString(array);
    		String encodedValue = URLEncoder.encode(jsonValue, "UTF-8");
//    		Cookie imageCookie = new Cookie(COOKIENAME, encodedValue);
//    		imageCookie.setMaxAge(60*60*24*3);
//    		imageCookie.setPath(req.getContextPath());
//    		resp.addCookie(imageCookie);
    		Cookie imageCookie = CookieUtils.createCookie(COOKIENAME,
    				jsonValue, req.getContextPath(), TextType.PATH, 60*60*24*3);
    		resp.addCookie(imageCookie);
    	}
    }   
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//파라미터에는 하나만 들어간다는 보장이 없으므로
		//value는 String[] -> 동일한 키에 여러 개의 value를 넘길 수 있다.
		//getParameter 종류 4개 모두 String 타입
		//getParameter -> 하나의 값만 뽑아냄
		//getParameterValue -> 여러 개의 값을 뽑아낼 수 있다.
		String imageName = request.getParameter("image");
		
		//url에서 imageView.do만 입력한 경우 클라이언트의 잘못임에도, 500에러 발생
		//이런 경우를 방지하기 위해 임의적으로 에러를 변경해서 클라이언트에게 알려줘야 함
		//필수 파라미터가 넘어왔는지 체크해야 함
		if(imageName == null || imageName.isEmpty()) {
			//파라미터가 넘어오지 않거나 없으면? 
			//내 잘못이 아니라 클라이언트 잘못이라는 것을 알려줘야 함
			response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			return;
		} 
		
		//읽을 정보를 가져옴
		File imageFile = new File(folder, imageName);
		
		if(!imageFile.exists()) {
			//이미지가 존재하지 않으면?
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			//404 처리
			return;
		}
		
		//image = test.txt를 입력한다면?
		if(!getServletContext().getMimeType(imageName).startsWith("image")) {
			//마임타입이 img가 아니라면?
//			response.sendError(HttpServletResponse.SC_BAD_REQUEST);
			response.sendError(400);
			return;
		}
		
		//httpservlet에 있는 api를 이용해 mime 타입 자동으로 가져오기
		String mime = getServletContext().getMimeType(imageFile.getName());
		
		//읽은 다음 내보내주는 작업 (파일의 끝을 만나기 전까지)
		//파일 계열의 inputStream 필요 (fileInputStream, fileReader)
		//문자가 아니므로 0,1을 읽은 fileInputStream을 써야 함
		response.setContentType(mime);
		 
		//try with resource형태로
		try(
			FileInputStream fis = new FileInputStream(imageFile);
			//반대쪽은 resp를 통해 받아와야 함
			//모든 출력 스트림의 최상위가 되어야 함
			OutputStream os = response.getOutputStream();
			//문자인 경우 Writer가 최상위
		){	
			//이렇게 하면 파일의 크기가 1byte이면 1번만 돌면 됨
			//버퍼가 계속 가지고 있음
			byte[] buffer = new byte[1024];
			//어디까지 읽었는지 체크하기 위한 용도
			int cnt = -1;
			//EOF(End of File)를 만날 때까지
			while ((cnt = fis.read(buffer)) != -1) {
				os.write(buffer, 0, cnt);
				//파일이 1024의 배수면 상관이 없다. 그런데 2.5byte라면?
				//3번 돌게된다. 이러면 3번째에는 버퍼가 반만 차게 된다. 이러면 2.6~3.0에는 전에 쓰던 데이터가 들어간다.(이미지 깨짐)
				//write(byte[], off, len) -> byte[]형식을, off부터 len까지 적는다.
				
			}
		}
		
	}


}
