package kr.or.ddit.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * Factory Object[Method] Pattern
 */
public class ConnectionFactory {
	private static String url;
	private static String user;
	private static String password;
	
	
	static { // 이게 먼저 실행됨
		ResourceBundle bundle =  ResourceBundle.getBundle("kr.or.ddit.db.dbInfo");
		String driverClassName = bundle.getString("driverClassName");
		url = bundle.getString("url");
		user = bundle.getString("user");
		password = bundle.getString("password");
		
		try {
			Class.forName(driverClassName);
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException {
		Connection conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
}
