package kr.or.ddit.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.AuthenticateServiceImpl;
import kr.or.ddit.member.service.IAuthenticateService;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.vo.MemberVO;

@WebServlet("/member/removeMember.do")
public class MemberDeleteController extends HttpServlet{
	private IMemberService memberService = MemberServiceImpl.getInstance();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String mem_pass = req.getParameter("mem_pass");
		if(StringUtils.isBlank(mem_pass)) {
			resp.sendError(400);
			return;
		}
		
		HttpSession session = req.getSession(false);
		if(session == null || session.isNew()) {
			resp.sendError(400);
			return;
		}
		MemberVO authMember = (MemberVO)session.getAttribute("authMember"); 
		String mem_id = authMember.getMem_id();
		
		ServiceResult result = memberService.removeMember(MemberVO.builder()
									.mem_id(mem_id)
									.mem_pass(mem_pass)
									.build());
		
		
		String goPage = null;
		switch (result) {
		case PKDUPLICATED:
			session.setAttribute("message", "비번 오류");
			goPage = "redirect:/mypage.do";
			break;
		case FAILED:	// 서버오류
			session.setAttribute("message", "서버 오류");
			goPage = "redirect:/mypage.do";
			break;
		default:
//			1. 세션 없애기 (만료)
//			2. 그리고 나서 웰컴페이지로 이동(index.jsp)
			goPage = "forward:/login/logout.do";
			break;
		}
		
//		if(result instanceof MemberVO) {
//			req.setAttribute("member", result);
//			goPage = req.getContextPath();
//		} else {
//			redirect = true;
//			session.setAttribute("message", "비번오류, 다시입력 요망");
//			goPage = "/mypage.do";
//		}
		
		boolean redirect = goPage.startsWith("redirect:");
		boolean forward = goPage.startsWith("forward:");
		if(redirect) {
			resp.sendRedirect(req.getContextPath()+goPage.substring("redirect:".length()));
		} else if(forward) {
			req.getRequestDispatcher(goPage.substring("forward:".length())).forward(req, resp);
		} else {
			req.getRequestDispatcher("/"+goPage+".tiles").forward(req, resp);
		}
	}
}

