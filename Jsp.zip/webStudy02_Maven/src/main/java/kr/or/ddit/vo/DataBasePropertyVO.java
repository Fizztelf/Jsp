package kr.or.ddit.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * DataBase property 하나의 정보를 담기 위한 Domain Layer 
 *
 */
//@Getter
//@Setter
@EqualsAndHashCode(of= {"property_name"})
@ToString(exclude= {"bytes"})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DataBasePropertyVO implements Serializable{
	private String property_name;
	private String property_value;
	private String description;
	
	@JsonIgnore	// 이걸 쓰면 직렬화 할때도 마샬링 할 때도 제외시킴.
	private transient byte[] bytes; // 직렬화 ㄴㄴ, lombok에 ToString에서 제외시켰으니까 직렬화도 하면 안돼
	
	
}
