package kr.or.ddit.member.controller;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.vo.MemberVO;


@WebServlet("/member/registMember.do")
public class MemberInsertController extends HttpServlet{
	
	private IMemberService service = MemberServiceImpl.getInstance();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String logicalView = "member/memberForm";
		req.getRequestDispatcher("/"+logicalView+".tiles").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		MemberVO member = new MemberVO();
		req.setAttribute("member", member); // 콜바이레퍼런스, 주소을 갖고있음
//		member.setMem_id(req.getParameter("mem_id"));
		Map<String, String[]> parameterMap = req.getParameterMap();
//		member.getClass() == MemberVO.class    이건 같은거야
		try {
			BeanUtils.populate(member, parameterMap);
		} catch (IllegalAccessException | InvocationTargetException e) {
			throw new ServletException(e);
		}
		
		Map<String, String> errors = new LinkedHashMap<>();
		req.setAttribute("errors", errors);
		boolean valid = validate(member, errors);
		boolean redirect = false;
		String goPage = null;
		
		if(valid) { // 검증통과
			ServiceResult result = service.registMember(member);
			switch (result) {
			case PKDUPLICATED:
				goPage = "member/memberForm";
				break;
			case FAILED:
				goPage = "member/memberForm";
				break;
			case OK:
				redirect = true;
				goPage = "/login/loginForm.do";
				
				break;
			}
		} else { // 검증을 안했다면 데이터의 길이를 제한했는데 그거에 맞지 않았다거나
			goPage = "member/memberForm";
		}
		
		if(redirect) {
			resp.sendRedirect(req.getContextPath()+goPage);
		} else { 
			req.getRequestDispatcher("/"+goPage+".tiles").forward(req, resp);
			
		}
		
//		Class<MemberVO> memberType = MemberVO.class;
//		parameterMap.keySet().iterator() ===== req.getParameterNames() // 같은 거야
		
//		Enumeration<String> names = req.getParameterNames();
//		while(names.hasMoreElements()) {
//			String parameterName = (String) names.nextElement();
//			String parameterValue = req.getParameter(parameterName);
//			
//			try {
//				PropertyDescriptor pd = new PropertyDescriptor(parameterName, memberType);
//				pd.getWriteMethod().invoke(member, parameterValue);
//			} catch (Exception e) {
//				continue;
//			}
//		}
	}

	private boolean validate(MemberVO member, Map<String, String> errors) {
		boolean valid = true;
		if(StringUtils.isBlank(member.getMem_id())) {
			valid = false;
			errors.put("mem_id", "아이디는 필수 입력");
		}
		
		if(StringUtils.isBlank(member.getMem_pass())) {
			valid = false;
			errors.put("mem_pass", "비번은 필수 입력");
		}
		
		return valid;
	}
}




























