package kr.or.ddit.member.controller;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.vo.MemberVO;

@WebServlet("/member/registMember.do")
public class MemberInsertController  extends HttpServlet {
   private IMemberService service = MemberServiceImpl.getInstance();
   @Override
   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      String logicalView = "member/memberForm";
      req.getRequestDispatcher("/"+logicalView+".tiles").forward(req, resp);
   }
   
   @Override
   protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
         throws ServletException, IOException {
      //특수문자 입력 -> 인코딩 설정 필요
      req.setCharacterEncoding("UTF-8");
      MemberVO member = new MemberVO();
      
      req.setAttribute("member", member);
//      member.setMem_id(req.getParameter("mem_id"));
      Map<String, String[]> parameterMap = req.getParameterMap();
      try {
         BeanUtils.populate(member, parameterMap);
      } catch (IllegalAccessException | InvocationTargetException e) {
         throw new ServletException(e);
      }
//     통과x 프로퍼티명, 에러메세지
      Map<String, String> errors = new LinkedHashMap<>();
      req.setAttribute("errors", errors);
      boolean valid = validate(member, errors);
      String goPage = null;
      
      if(valid) {
         ServiceResult result = service.registMember(member);
         switch (result) {
         case PKDUPLICATED:
            goPage = "member/memberForm";
            break;
         case FAILED:
            goPage = "member/memberForm";
            break;
         case OK:
            goPage =  "redirect:/login/loginForm.do";
            break;
         }
      }else {
         goPage = "member/memberForm";
      }
      
      boolean redirect = goPage.startsWith("redirect:");
		boolean forward = goPage.startsWith("forward:");
		if(redirect) {
			resp.sendRedirect(req.getContextPath()+goPage.substring("redirect:".length()));
		} else if(forward) {
			req.getRequestDispatcher(goPage.substring("forward:".length())).forward(req, resp);
		} else {
			req.getRequestDispatcher("/"+goPage+".tiles").forward(req, resp);
		}
   }

   private boolean validate(MemberVO member, Map<String, String> errors) {
      boolean valid = true;
      if(StringUtils.isBlank(member.getMem_id())) {
         valid = false;
         errors.put("mem_id", "아이디는 필수입력");
      }
      if(StringUtils.isBlank(member.getMem_pass())) {
         valid = false;
         errors.put("mem_pass", "비밀번호는 필수입력");
      }
      if(StringUtils.isBlank(member.getMem_name())) {
         valid = false;
         errors.put("mem_name", "이름은 필수입력");
      }
      if(StringUtils.isBlank(member.getMem_regno1())) {
    	  valid = false;
    	  errors.put("mem_regno1", "주민번호1 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_regno2())) {
    	  valid = false;
    	  errors.put("mem_regno2", "주민번호2 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_zip())) {
    	  valid = false;
    	  errors.put("mem_zip", "집코드 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_add1())) {
    	  valid = false;
    	  errors.put("mem_add1", "주소1 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_add2())) {
    	  valid = false;
    	  errors.put("mem_add2", "주소2 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_hometel())) {
    	  valid = false;
    	  errors.put("mem_hometel", "집전화 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_comtel())) {
    	  valid = false;
    	  errors.put("mem_comtel", "com번호 필수 입력");
      }
      if(StringUtils.isBlank(member.getMem_mail())) {
    	  valid = false;
    	  errors.put("mem_mail", "메일 필수 입력");
      }
      
      return valid;
   }
}




