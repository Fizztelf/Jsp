package kr.or.ddit.explorer;

import java.io.File;

public class FileWrapper extends File{

	public FileWrapper(File adaptee, String relativePath) {
		super(adaptee.getAbsolutePath());
		this.relativePath = relativePath;
		this.clzName = adaptee.isDirectory()?"folder":"file";
	}
	
	private String clzName;
	private String relativePath;
	
	public String getRelativePath() {
		return relativePath;
	}
	public String getClzName() {
		return clzName;
	}
}