package kr.or.ddit.servlet02;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.enumpkg.MimeType;

//이런 파일은 없다. URL X / URI O
@WebServlet("/02/getMessage.do")
public class GetMessageServlet extends HttpServlet{
//	public static enum MimeType{
//		HTML("text/html;charset=utf-8")
//		,PLAIN("text/plain;charset=utf-8")//text가 많으므로 겹친다.
//		,XML("application/xml;charset=utf-8") //text/xml도 가능
//		,JSON("application/json;charset=utf-8") //text/json도 가능
//		,JAVASCRIPT("text/html;charset=utf-8");
//		//각각의 NAME값을 가진다.
//		//해당하는 마임타입은 없는 상태
//		
//		private String mime;
//
//		private MimeType(String mime) {
//			this.mime = mime;
//		}
//		
//		//상수에 해당하는 마임을 받아갈 수 있다.
//		public String getMime() {
//			return mime;
//		}
//		
//		@Override
//		public String toString() {
//			return getMime();
//		}
//		
//		
//		//static 객체 생성 없이 접근하기 위해서
//		//accept헤더 파싱해서 적절한 마임으로 내보내는 메서드
//		public static MimeType parseAcceptToMimeType(HttpServletRequest req){
//			//헤더 받아오기(파싱할 것들)
//			String accept = req.getHeader("Accept");
//			MimeType mime = MimeType.HTML; //HTML로 기본값을 잡아놓은 것
//			
//			for (MimeType tmp : values()) {
//				//각 함수의 이름을 사용할 수 있다.
//				if(accept.toUpperCase().contains(tmp.name())) {
//					//마입을 찾았다면
//					mime = tmp;
//					break;
//				}
//			}
//			return mime;
//		}
//		
//	}
	
	@Override
	protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getOutputStream().close();  // 버퍼를 플러쉬 하겠다. 바디가 없음
	}
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		MimeType contentType = MimeType.parseAcceptToMimeType(req);
		resp.setContentType(contentType.toString());
		//
		
		String language = req.getParameter("lang");
		String acceptLanguage = req.getHeader("accept-language");
		Locale locale = req.getLocale();
		if(language != null && !language.isEmpty()){
			locale = locale.forLanguageTag(language.toLowerCase());
		}
		ResourceBundle bundle = ResourceBundle.getBundle("kr.or.ddit.msg.message", locale);
		//응답 데이터가 text/html인 경우에 사용한다.
		//응답데이터가 html이 아니면 jsp를 쓸 이유가 없다.***********
		//얘를 jsp로 보내야 함 scope 이용 jsp로 전송
		String message = bundle.getString("bow");
		if(MimeType.PLAIN.equals(contentType)) {
			//== -> 값을 비교 equals -> 주소를 비교
			//그러나 enum에서는 둘이 똑같다.
			try(
				PrintWriter out = resp.getWriter();
			){
				out.println(message);
			}
		}else if(MimeType.JSON.equals(contentType)){
			Map<String, Object> data = new HashMap<>();
			data.put("message", message);
			//자바 데이터 -> json 데이터 형식으로 바꿔야 함 
			//마샬링 -> 네이티브 언어로 표현되고 있는 방식을 공통적 표현 방식으로 바꾸는 것(번역 과정) / 언마샬링
			// {"message" : "데이터"}
			StringBuffer json = new StringBuffer();
			String propPtrn = " \"%s\" : \"%s\"  ";
			json.append("{");
			for( Entry<String, Object> entry : data.entrySet()) {
				String name = entry.getKey(); 
				//형식이 고정된 문자열을 만들 때는 .format()
				Object value = entry.getValue();
				json.append(String.format(propPtrn, name, value));
				json.append(", ");
			}
			int lastIdx = json.lastIndexOf(",");
			json.deleteCharAt(lastIdx);
			json.append("}");
			try(
					PrintWriter out = resp.getWriter();
				){
					out.println(json);
				}
		}else if(MimeType.XML.equals(contentType)){
			//마샬링
			//태그가 필요하므로 마샬링의 대상이 커진다.
			Map<String, Object> data = new HashMap<>();
			data.put("message", message);
			StringBuffer xml = new StringBuffer();
			String propPtrn = "<%1$s>%2$s</%1$s>";
			xml.append("<root>");
			for( Entry<String, Object> entry: data.entrySet()) {
				String name = entry.getKey(); 
				Object value = entry.getValue();
				xml.append(String.format(propPtrn, name, value));
			}
			xml.append("</root>");
			try(
					PrintWriter out = resp.getWriter();
				){
					out.println(xml);
				}
			
		}else {
			req.setAttribute("message", message);
			String view = "/WEB-INF/views/getMessage.jsp";
			
			req.getRequestDispatcher(view).forward(req, resp);
		}
		
		//응답 데이터가 text/plain인 경우에 사용해야 한다.
	}
}
