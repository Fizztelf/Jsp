package kr.or.ddit.prod.service;

import java.util.List;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.prod.dao.IProdDAO;
import kr.or.ddit.prod.dao.ProdDAOImpl;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ProdVO;

public class ProdServiceImpl implements IProdService {
	private ProdServiceImpl() {}
	private static ProdServiceImpl self;
	public static ProdServiceImpl getInstance() {
		if(self==null) self = new ProdServiceImpl();
		return self;
	}

	private IProdDAO dao = ProdDAOImpl.getInstance();
	
	@Override
	public ServiceResult createProd(ProdVO prodVO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int retrieveProdCount(PagingVO<ProdVO> pagingVO) {
		return dao.selectProdCount(pagingVO);
	}

	@Override
	public List<ProdVO> retrieveProdList(PagingVO<ProdVO> pagingVO) {
		return dao.selectProdList(pagingVO);
	}

	@Override
	public ProdVO retrieveProd(String prod_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServiceResult modifyProd(ProdVO prod) {
		// TODO Auto-generated method stub
		return null;
	}

}
