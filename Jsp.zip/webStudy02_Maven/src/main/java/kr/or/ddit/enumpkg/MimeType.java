package kr.or.ddit.enumpkg;

import javax.servlet.http.HttpServletRequest;

public enum MimeType{
	HTML("text/html;charset=utf-8")
	,PLAIN("text/plain;charset=utf-8")//text가 많으므로 겹친다.
	,XML("application/xml;charset=utf-8") //text/xml도 가능
	,JSON("application/json;charset=utf-8") //text/json도 가능
	,JAVASCRIPT("text/html;charset=utf-8");
	//각각의 NAME값을 가진다.
	//해당하는 마임타입은 없는 상태
	
	private String mime;

	private MimeType(String mime) {
		this.mime = mime;
	}
	
	//상수에 해당하는 마임을 받아갈 수 있다.
	public String getMime() {
		return mime;
	}
	
	@Override
	public String toString() {
		return getMime();
	}
	
	
	//static 객체 생성 없이 접근하기 위해서
	//accept헤더 파싱해서 적절한 마임으로 내보내는 메서드
	public static MimeType parseAcceptToMimeType(HttpServletRequest req){
		//헤더 받아오기(파싱할 것들)
		String accept = req.getHeader("Accept");
		MimeType mime = MimeType.HTML; //HTML로 기본값을 잡아놓은 것
		
		for (MimeType tmp : values()) {
			//각 함수의 이름을 사용할 수 있다.
			if(accept.toUpperCase().contains(tmp.name())) {
				//마입을 찾았다면
				mime = tmp;
				break;
			}
		}
		return mime;
	}
	
}
