package kr.or.ddit.member.controller;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.vo.MemberVO;

@WebServlet("/member/modifyMember.do")
public class MemberUpdateController extends HttpServlet{
	
	private IMemberService memberService = MemberServiceImpl.getInstance();
	
	private void addCommanAttribute(HttpServletRequest req) {
		req.setAttribute("command", "MODIFY");
		
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		addCommanAttribute(req);
		
		String logicalView = "member/memberForm";
	    req.getRequestDispatcher("/"+logicalView+".tiles").forward(req, resp);
		
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		addCommanAttribute(req);
		String mem_pass = req.getParameter("mem_pass");
		if(StringUtils.isBlank(mem_pass)) {
			resp.sendError(400);
			return;
		}
		
		HttpSession session = req.getSession(false);
		if(session == null || session.isNew()) {
			resp.sendError(400);
			return;
		}
		MemberVO authMember = (MemberVO)session.getAttribute("authMember"); 
		String mem_id = authMember.getMem_id();
		
		ServiceResult result = memberService.removeMember(MemberVO.builder()
									.mem_id(mem_id)
									.mem_pass(mem_pass)
									.build());
		
//		boolean valid = validate(member, errors);
		String goPage = null;
		switch (result) {
		case PKDUPLICATED:
			session.setAttribute("message", "비번 오류");
			goPage = "redirect:member/memberForm";
			break;
		case FAILED:	// 서버오류
			session.setAttribute("message", "서버 오류");
			goPage = "redirect:member/memberForm";
			break;
		default:
			goPage = "forward:/login/loginForm.do";
			break;
		}
		
		
		boolean redirect = goPage.startsWith("redirect:");
		boolean forward = goPage.startsWith("forward:");
		if(redirect) {
			resp.sendRedirect(req.getContextPath()+goPage.substring("redirect:".length()));
		} else if(forward) {
			req.getRequestDispatcher(goPage.substring("forward:".length())).forward(req, resp);
		} else {
			req.getRequestDispatcher("/"+goPage+".tiles").forward(req, resp);
		}
	}
	private boolean validate(MemberVO member, Map<String, String> errors) {
	      boolean valid = true;
	      if(StringUtils.isBlank(member.getMem_id())) {
	         valid = false;
	         errors.put("mem_id", "아이디는 필수입력");
	      }
	      if(StringUtils.isBlank(member.getMem_pass())) {
	         valid = false;
	         errors.put("mem_pass", "비밀번호는 필수입력");
	      }
	      if(StringUtils.isBlank(member.getMem_name())) {
	         valid = false;
	         errors.put("mem_name", "이름은 필수입력");
	      }
	      if(StringUtils.isBlank(member.getMem_regno1())) {
	    	  valid = false;
	    	  errors.put("mem_regno1", "주민번호1 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_regno2())) {
	    	  valid = false;
	    	  errors.put("mem_regno2", "주민번호2 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_zip())) {
	    	  valid = false;
	    	  errors.put("mem_zip", "집코드 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_add1())) {
	    	  valid = false;
	    	  errors.put("mem_add1", "주소1 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_add2())) {
	    	  valid = false;
	    	  errors.put("mem_add2", "주소2 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_hometel())) {
	    	  valid = false;
	    	  errors.put("mem_hometel", "집전화 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_comtel())) {
	    	  valid = false;
	    	  errors.put("mem_comtel", "com번호 필수 입력");
	      }
	      if(StringUtils.isBlank(member.getMem_mail())) {
	    	  valid = false;
	    	  errors.put("mem_mail", "메일 필수 입력");
	      }
	      
	      return valid;
	   }
	
}
