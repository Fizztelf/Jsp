package kr.or.ddit.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class SecurityUtils {
	public static String encryptSha512(String plain) {
//		1. 단방향 (해시 함수) : 다양한 입력 데이터를 일정 길이의 해시 코드로 생성할 때 사용
//		비밀번호를 저장할 때 단방향을 많이 사용한다.
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			byte[] encrypted = md.digest(plain.getBytes());
			System.out.println(encrypted.length);
			String encoded = Base64.getEncoder().encodeToString(encrypted);
			return encoded;
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}
}
