/**
 * 
 */
$.timeToText = function(time){
	let min = Math.trunc(time/60);
	let sec = time%60;
	return min + ":" + sec;
}

$.fn.sessionTimer = function(param){
	const TIMEOUT = param.timeout;
	const SESSIONURL = param.sessionURL;
	$.init = function(){
		time = TIMEOUT;
		timeoutId = setTimeout(function(){
			msgArea.show();
			timeoutId = null;
		}, (TIMEOUT-60)*TIMEUNIT);
	}
	const TIMEUNIT = 100;
	let time = TIMEOUT;
	let timeArea = this;
	
//	let msgBtn = [];
//	msgBtn.push($("<button>").prop("id","yes").addClass("msgBtn").text("예"));
//	msgBtn.push($("<button>").prop("id","no").addClass("msgBtn").text("아니요"));
//	let msgArea = $("<div>").prop("id","msgArea").html("세션 연장할껴? 말껴?").append(msgBtn).hide();
	let msgArea = $.parseHTML(MSGMODALSRC);
//	console.log(msgArea);
//	let msgArea = $("<div>").html(MSGMODALSRC).find("#msgArea").modal();
	$(document).append(msgArea);
	msgArea.modal("show");
	msgArea.on("click", ".msgBtn",function(){
//		$(this).closest("div").hide();
		msgArea.hide();
		if(this.id == "yes"){
			$.ajax({
				url : SESSIONURL,
				method : "head"
			}).done(function(){
				$.init();
			});
		}
	});
	$.init();
	jobId = setInterval(() => {
		if(time == 0){
			clearInterval(jobId);
		} else {
			timeArea.text($.timeToText(--time));
		}
	}, TIMEUNIT);
	return this;
}

const MSGMODALSRC =  
'<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">'+
'<div class="modal-dialog">                                                                                     '+
'  <div class="modal-content">                                                                                  '+
'    <div class="modal-header">                                                                                 '+
'      <h5 class="modal-title" id="messageModalLabel">Modal title</h5>                                          '+
'    </div>                                                                                                     '+
'    <div class="modal-body">                                                                                   '+
'    	세션 연장?                                                                                              '+
'    </div>                                                                                                     '+
'    <div class="modal-footer">                                                                                 '+
'    	<button class="msgBtn" id="yes">예</button>                                                             '+
'    	<button class="msgBtn" id="no">아니요</button>                                                          '+
'    </div>                                                                                                     '+
'  </div>                                                                                                       '+
'</div>                                                                                                         '+
'</div>                                                                                                         ';