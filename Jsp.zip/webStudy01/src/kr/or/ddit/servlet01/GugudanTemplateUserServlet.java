package kr.or.ddit.servlet01;

import java.io.File;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

public class GugudanTemplateUserServlet extends UseTemplateServlet {

	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	
	@Override
	public String getMimeType() {
		return "text/html;charset=UTF-8";
	}

	@Override
	public void getDataMap(Map<String, Object> dataMap) {
	}
}
