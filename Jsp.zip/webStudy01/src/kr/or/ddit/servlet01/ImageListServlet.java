package kr.or.ddit.servlet01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xalan.internal.xsltc.compiler.Template;

import kr.or.ddit.utils.TemplateUtils;

//@WebServlet("/01/imageList.tmpl")
public class ImageListServlet extends UseTempleteServlet {
	File folder; // 전역 변수 선언 후 한번만 호출하면 되는 init 오버라이드

	@Override
	public void init(ServletConfig config) throws ServletException {
		// 반드시 있어야 함
		super.init(config);
		String contentFolder = getServletContext().getInitParameter("contentFolder");
//			String contentFolder = config.getInitParameter("contentFolder");
		folder = new File(contentFolder);
	}

	@Override
	public String getMimeType() {
		return "text/html;charset=UTF-8";
	}

	/**
	 * request callback에 해당 매번 재실행됨 -> File folder = new File("d:/contents"); 매번 호출할
	 * 필요 없다. 한번 실행할 수 있는 곳으로 뺀다. -> init 오버라이딩 후 보낸다.
	 */
	@Override
	public void getDataMap(Map<String, Object> dataMap, HttpServletRequest req) {

		// 하드코딩 시의 문제점 : 컨텐츠 폴더의 위치가 바뀌면 관련 소스를 모두 바꿔야 함.
		String[] imageList = folder.list((dir, name) -> {
			String mime = getServletContext().getMimeType(name);
			return mime != null && mime.startsWith("image");
		});

		String pattern = "<option value='%1$s'>%1$s</option>";
		StringBuffer options = new StringBuffer("");
		for (String filename : imageList) {
			options.append(String.format(pattern, filename, filename));
		}

		dataMap.put("title", "이미지 목록");
		dataMap.put("optionData", options);
		dataMap.put("today", new Date());
	}

}