package kr.or.ddit.servlet01;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.utils.TemplateUtils;

public abstract class UseTemplateServlet extends HttpServlet {
	@Override
	protected final void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 메소드와 상관없이 무조건 실행하는 것 service!
		response.setContentType(getMimeType());
		Map<String, Object> dataMap = new HashMap<>();
		
		Map<String, String[]> parameterMap =  request.getParameterMap();
//		dataMap.putAll(parameterMap);
		for(Entry<String, String[]> entry : parameterMap.entrySet()) {
			String paramName = entry.getKey();
			String[] paramValues = entry.getValue();
			dataMap.put(paramName, paramValues.length==1?paramValues[0]:paramValues);
		}
		
		getDataMap(dataMap, request);

		String html = TemplateUtils.replaceTemplateToData(request, dataMap);

		try (PrintWriter out = response.getWriter();) {
			out.println(html);
		}
	}

	public abstract String getMimeType();

	public abstract void getDataMap(Map<String, Object> dataMap, HttpServletRequest req);
}

