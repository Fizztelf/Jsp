package kr.or.ddit.servlet01;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.utils.TemplateUtils;

public abstract class UseTemplateServlet extends HttpServlet {
	@Override
	protected final void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 메소드와 상관없이 무조건 실행하는 것 service!
		response.setContentType(getMimeType());
		Map<String, Object> dataMap = new HashMap<>();
		
		getDataMap(dataMap);

		String html = TemplateUtils.replaceTemplateToData(request, dataMap);

		try (PrintWriter out = response.getWriter();) {
			out.println(html);
		}
	}

	public abstract String getMimeType();

	public abstract void getDataMap(Map<String, Object> dataMap);
}

