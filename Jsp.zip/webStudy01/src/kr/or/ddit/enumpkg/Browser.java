package kr.or.ddit.enumpkg;


//방법 3 ENUM -> 컴파일러에 의해 클래스로 바뀜. 동시에 static 메서드가 자동으로 할당된다.
//전역변수를 만들기 위해서 사용한다.
//자기 타입의 객체를 미리 만들어놓는다. ENUM 안에 있는 것들은 외부에서 다시 생성할 수 없다.
public enum Browser{
	//열거형 상수가 필요하다. (타입은 Browser)
	EDG("엣지"), CHROME("크롬"), TRIDENT("익스플로러"), OTHER("기타");
	
	private String browserName;
	//private으로 만들어놓은 것에 값을 넣는법
	//1)getter,setter
	//2)생성자
	Browser(String browserName){
		this.browserName = browserName;
	}
	public String getBrowser(){
		return browserName;
	}
	
	//방법 4 ENUM 다른 방식
	public static String getBrowserName(String agent){
	 	Browser[] browsers = values();
	 	Browser finded = OTHER;
	 	for(Browser temp : browsers){
	 		if(agent.toUpperCase().contains(temp.name())){
	 			finded = temp;
	 			break;
	 		}
	 	}
	 	return finded.getBrowser();
	}
}