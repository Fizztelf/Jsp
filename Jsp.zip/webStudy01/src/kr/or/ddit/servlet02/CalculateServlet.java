package kr.or.ddit.servlet02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.enumpkg.OperateType;

@WebServlet("/03/calculate.do")
public class CalculateServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String left = req.getParameter("leftOp");
		String right = req.getParameter("rightOp");
		String opParam = req.getParameter("operator");
		int status = HttpServletResponse.SC_OK;
		String message = null;
		
		if(left == null || !left.matches("[0-9]+")) { // 숫자가 들어왔거나 아무것도 안들어왔거나
			status = HttpServletResponse.SC_BAD_REQUEST;
			message = "좌측 피연산자 누락";
		}
		if(right == null || !right.matches("[0-9]+")) { // 숫자가 들어왔거나 아무것도 안들어왔거나
			status = HttpServletResponse.SC_BAD_REQUEST;
			message = "우측 피연산자 누락";
		}
		
		OperateType operator = null;
		if(opParam == null || opParam.isEmpty()) {
			status = HttpServletResponse.SC_BAD_REQUEST;
			message = "연산자 누락";
		} else {
			try {
				operator = OperateType.valueOf(opParam);
			} catch(IllegalArgumentException e) {
				// 연산자를 잘못넣은거
				status = HttpServletResponse.SC_BAD_REQUEST;
			}
		}
		
		if(status != HttpServletResponse.SC_OK) {
			resp.sendError(status, message);
			return;
		}
		
		int leftOp = Integer.parseInt(left);
		int rightOp = Integer.parseInt(right);
		int result = operator.operator(leftOp, rightOp);
		
		
		String exprPtrn = "%d %s %d = %d";
		String responseData = String.format(exprPtrn, leftOp, operator.getSign(), rightOp, result);
		try(
			PrintWriter out = resp.getWriter();
		){
			out.println(responseData);
		}
	}
}





















