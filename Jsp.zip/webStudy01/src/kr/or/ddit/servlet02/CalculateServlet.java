package kr.or.ddit.servlet02;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.enumpkg.MimeType;
import kr.or.ddit.enumpkg.OperateType;
import kr.or.ddit.utils.JsonResponseUtils;

//모델 2구조 서블릿의 역할
		// 1. 요청 분석
		// 2. 요청이 필요로 하는 데이터 만들기
		// 3. 데이터를 필요로 하는 UI를 만들어주는 JSP로 보내기 (web-inf 하위)
		// 4. 뷰 결정(/WEB-INF/views/calculate.jsp) -> 이동

@WebServlet("/03/calculate.do")
public class CalculateServlet extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//마임타입 가져오기
		MimeType mime = MimeType.parseAcceptToMimeType(req);
		resp.setContentType(mime.toString());
		
		String left = req.getParameter("leftOp");
		String right = req.getParameter("rightOp");
		String opParam = req.getParameter("operator");
		
		int status = HttpServletResponse.SC_OK;
		String msg = null;
		
		if(left == null || !left.matches("[0-9]+")) {
			status = HttpServletResponse.SC_BAD_REQUEST;
			msg = "좌측 피연산자 누락";
		}
		if(right == null || !right.matches("[0-9]+")) {
			status = HttpServletResponse.SC_BAD_REQUEST;
			msg = "우측 피연산자 누락";
		}
		OperateType operator = null;
		if(opParam == null || opParam.isEmpty()) {
			status = HttpServletResponse.SC_BAD_REQUEST;
			msg = "연산자 누락";
		}else {//opParam이 데이터를 가지고 있다면?
			//name값을 받아서 해당하는 값이 있다면 그 값을 돌려주는 메서드
			try {
				//asdfasdf에 대한 valueOf의 대답은 exception
				operator = OperateType.valueOf(opParam);
			} catch (IllegalArgumentException e) {
				//param이 잘못되었음을 알리기 위한 exception
				status = HttpServletResponse.SC_BAD_REQUEST;
			}
		}
		
		//opParam에 대한 검증 필요
		if(status!=HttpServletResponse.SC_OK) {
			resp.sendError(status, msg);
			return;
		}
		
		//검증하기
		int leftOp = Integer.parseInt(left);
		int rightOp = Integer.parseInt(right);
		int result = operator.operator(leftOp, rightOp);
		
		// mimeType받아오기 Request Header에서 Accept
		// response Header에 CotentType에 mimeType설정
		
		// HTML, JSON 분기 (ENUM이용해서)
		
		// HTML
		// HTML만드는 VIEW를 선택해서 Dispatcher
		
		// JSON
		// JSON은 key/value
		// Map을써서 key/value로 관리해주고 String.format으로 parsing해서 out.println()
		
		String exprPtrn = "%d %s %d = %d";
		String responseData = String.format(exprPtrn, leftOp, operator.getSign(), rightOp, result);
		Date now = new Date();
		req.setAttribute("now", now);
		req.setAttribute("data", responseData);
		//가짜주소 = /webStudy01/WebContent
//		/webStudy01/WebContent/WEB-INF/views/calculate.jsp
		if(MimeType.HTML == mime) {
			String view = "/WEB-INF/views/calculate.jsp";
			req.getRequestDispatcher(view).forward(req, resp);
		}else if(MimeType.JSON == mime) {
			//static의 영향으로 객체 생성 없이도 접근 가능
			JsonResponseUtils.toJsonResponse(req, resp);
		}
		
//		try(
//			PrintWriter out = resp.getWriter();	
//		){
//			out.println(responseData);
//		}
		
		
	}

	
}
