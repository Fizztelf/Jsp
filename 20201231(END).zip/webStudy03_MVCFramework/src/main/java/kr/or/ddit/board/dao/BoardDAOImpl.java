package kr.or.ddit.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.vo.BoardVO;
import kr.or.ddit.vo.PagingVO;

public class BoardDAOImpl implements IBoardDAO {
	private BoardDAOImpl() { }
	private static BoardDAOImpl self;
	public static BoardDAOImpl getInstance() {
		if(self==null) self = new BoardDAOImpl();
		return self;
	}
	
	private SqlSessionFactory sqlSessionFactory = 
			CustomSqlSessionFactoryBuilder.getSqlSessionFactory();
	@Override
	public int insertBoard(BoardVO board, SqlSession sqlSession) {
		return sqlSession.insert("kr.or.ddit.board.dao.IBoardDAO.insertBoard", board);
	}

	@Override
	public int selectBoardCount(PagingVO<BoardVO> paging) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.selectBoardCount(paging);
		}
	}

	@Override
	public List<BoardVO> selectBoardList(PagingVO<BoardVO> paging) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.selectBoardList(paging);
		}
	}

	@Override
	public BoardVO selectBoard(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession();) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.selectBoard(bo_no);
		}
	}
	
	@Override
	public int incrementHit(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.incrementHit(bo_no);
		}
	}


	@Override
	public int updateBoard(BoardVO board) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.updateBoard(board);
		}
	}

	@Override
	public int deleteBoard(int bo_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int incrementRecCnt(int bo_no) {
		try (SqlSession sqlSession = sqlSessionFactory.openSession(true);) {
			IBoardDAO mapper = sqlSession.getMapper(IBoardDAO.class);
			return mapper.incrementRecCnt(bo_no);
		}
	}
}
