package kr.or.ddit.listener;

import java.io.File;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.tiles.web.startup.simple.SimpleTilesListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.prod.service.IProdService;
import kr.or.ddit.prod.service.ProdServiceImpl;

public class CustomServletContextListener extends SimpleTilesListener{
	
	private static final Logger logger = LoggerFactory.getLogger(CustomServletContextListener.class);

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		super.contextInitialized(sce);
		ServletContext application = sce.getServletContext();
		application.setAttribute("cPath", application.getContextPath());
		
		ProdServiceImpl service = ProdServiceImpl.getInstance();
		String saveFolderUrl = "/prodImages";
		File saveFolder = new File(application.getRealPath(saveFolderUrl));
		service.setSaveFolder(saveFolder);
		if(!saveFolder.exists()) {
			saveFolder.mkdirs();
		}
		logger.info("{} 가 초기화 되면서 saveFolder 를 ProdServiceImpl에 넣었음.", getClass().getSimpleName());
	}

}
















