package kr.or.ddit.commons.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import kr.or.ddit.commons.service.ISearchZipService;
import kr.or.ddit.commons.service.SearchZipServiceImpl;
import kr.or.ddit.utils.JsonResponseUtils;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.SearchVO;
import kr.or.ddit.vo.ZipVO;

@WebServlet("/commons/searchZip.do")
public class SearchZipController extends HttpServlet{
	private ISearchZipService service = SearchZipServiceImpl.getInstance();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		
		String draw = req.getParameter("draw");
		String length = req.getParameter("length");
		String start = req.getParameter("start");
		String searchWord = req.getParameter("search[value]");
		
		int screenSize = StringUtils.isNumeric(length)?Integer.parseInt(length) : 7;
		int currentPage = StringUtils.isNumeric(start)?Integer.parseInt(start)/screenSize + 1 : 1;
			
		PagingVO<ZipVO> pagingVO = new PagingVO<>(screenSize, 5);
		// 검색 전 레코드 수
		int recordsTotal = service.retrieveZipCount(pagingVO);
		
		pagingVO.setCurrentPage(currentPage);
		pagingVO.setSearchVO(new SearchVO(null, searchWord));
		// 검색 후 레코드 수
		int recordsFiltered = service.retrieveZipCount(pagingVO);
		
		List<ZipVO> zipList = service.retrieveZipList(pagingVO);
		
		req.setAttribute("draw", draw);
		req.setAttribute("recordsTotal", recordsTotal);
		req.setAttribute("recordsFiltered", recordsFiltered);
		req.setAttribute("data", zipList);
		
		
		JsonResponseUtils.toJsonResponse(req, resp);
	
	}
}













