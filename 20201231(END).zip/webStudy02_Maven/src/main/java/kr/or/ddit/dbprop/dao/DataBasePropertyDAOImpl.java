package kr.or.ddit.dbprop.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import kr.or.ddit.db.mybatis.CustomSqlSessionFactoryBuilder;
import kr.or.ddit.vo.DataBasePropertyVO;

public class DataBasePropertyDAOImpl implements IDataBasePropertyDAO {
	private DataBasePropertyDAOImpl() { }
	private static DataBasePropertyDAOImpl self;
	public static DataBasePropertyDAOImpl getInstance() {
		if(self==null) self = new DataBasePropertyDAOImpl();
		return self;
	}

	private SqlSessionFactory sqlSessionFactory = 
			CustomSqlSessionFactoryBuilder.getSqlSessionFactory();
	@Override
	public List<DataBasePropertyVO> selectDBProperties(DataBasePropertyVO paramVO) {
		try(
			SqlSession sqlSession = sqlSessionFactory.openSession();
		){		
			IDataBasePropertyDAO mapper = sqlSession.getMapper(IDataBasePropertyDAO.class);
			return mapper.selectDBProperties(paramVO);
		}
	}
}










