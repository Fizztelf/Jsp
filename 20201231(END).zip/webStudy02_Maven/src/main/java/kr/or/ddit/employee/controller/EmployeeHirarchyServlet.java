package kr.or.ddit.employee.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.ddit.employee.dao.EmployeeDAOImpl;
import kr.or.ddit.employee.dao.IEmployeeDAO;
import kr.or.ddit.vo.EmployeeVO;

@WebServlet("/employees/hirarchy.do")
public class EmployeeHirarchyServlet extends HttpServlet{
	IEmployeeDAO dao = new EmployeeDAOImpl();
	
	private  ServletContext application;
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		application = getServletContext();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String manager_id = req.getParameter("base");
		
		List<EmployeeVO> list = dao.selectEmployeeHierarchy(manager_id);
		
		String accept = req.getHeader("Accept");
		if(StringUtils.containsIgnoreCase(accept, "json")) {
			resp.setContentType("application/json;charset=UTF-8");
			try(
				PrintWriter out = resp.getWriter();	
			){
				ObjectMapper mapper = new ObjectMapper();
				mapper.writeValue(out, list);
			}
			
		}else {
			req.setAttribute("children", list);
			String logicalView = "employee/hirarchy";
			req.getRequestDispatcher("/"+logicalView+".tiles").forward(req, resp);
		}
		
	}
}
















