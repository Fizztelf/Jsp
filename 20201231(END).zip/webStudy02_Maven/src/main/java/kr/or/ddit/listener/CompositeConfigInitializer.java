package kr.or.ddit.listener;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class CompositeConfigInitializer implements ServletContextListener {


    public void contextInitialized(ServletContextEvent sce)  {
    	ServletContext application = sce.getServletContext();
    	System.out.printf("%s 초기화\n", application.getContextPath());
    	Properties properties = new Properties();
    	application.setAttribute("compositeConfig", properties);
    	try(
			InputStream is = application.getClassLoader().getResourceAsStream("compositeConfig.xml");
    	) {
			properties.loadFromXML(is);
			
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
    	
    }
    
    public void contextDestroyed(ServletContextEvent sce)  { 
    	ServletContext application = sce.getServletContext();
    	System.out.printf("%s 소멸\n", application.getContextPath());
    }

	
}










