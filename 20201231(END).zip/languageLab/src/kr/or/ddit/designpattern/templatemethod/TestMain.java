package kr.or.ddit.designpattern.templatemethod;

public class TestMain {
	public static void main(String[] args) {
		TemplateClass[] jobs = new TemplateClass[4];
		for(int i=0; i<jobs.length; i++) {
			if(i<2) {
				jobs[i] = new ConcreteClass1();
			}else {
				jobs[i] = new ConcreteClass2();
			}
		}
		for(TemplateClass job : jobs) {
			job.template();
		}
	}
}








