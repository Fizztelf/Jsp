package kr.or.ddit.designpattern.templatemethod;

import java.util.Calendar;

public class Test {
	public static void main(String[] args) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2021);
//		cal.set(Calendar.DATE, 1);
		cal.set(Calendar.MONTH, 1);
		System.out.printf("%tc", cal);
	}
}
