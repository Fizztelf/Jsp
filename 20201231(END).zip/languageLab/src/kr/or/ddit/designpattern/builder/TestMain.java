package kr.or.ddit.designpattern.builder;

/**
 * 객체 생성 및 상태 정의 방법
 * 1. 자바빈 규약에 따른 생성
 * 2. 점층적 생성자 
 * 3. Builder pattern 
 *
 */
public class TestMain {
	public static void main(String[] args) {
//		BtsVO rm = new BtsVO();
//		rm.setCode("B001");
//		rm.setName("RM");
//		rm.setUrl("/bts/rm.jsp");
//		
//		BtsVO rm = new BtsVO("B001", "RM", "/bts/rm.jsp");
//		rm.setName("정국");
		
		BtsVO rm = BtsVO.getBuilder()
						.code("B001")
						.name("RM")
						.url("/bts/rm.jsp")
						.build();
		System.out.println(rm);
	}
}




















