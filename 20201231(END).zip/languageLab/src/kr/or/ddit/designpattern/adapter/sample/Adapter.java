package kr.or.ddit.designpattern.adapter.sample;

public class Adapter implements Target {
	
	private Adaptee adaptee;

//	wrapper , int i =3 / Integer i = new Integer(3);
	public Adapter(Adaptee adaptee) {
		this.adaptee = adaptee;
	}


	@Override
	public void request() {
		adaptee.specificRequest();
	}

}







