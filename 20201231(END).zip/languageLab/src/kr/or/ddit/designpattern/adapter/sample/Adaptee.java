package kr.or.ddit.designpattern.adapter.sample;

public class Adaptee {
	public void specificRequest() {
		System.out.println(getClass().getSimpleName()+"에서만 독특하게 처리할 수 있는 요청 수행");
	}
}
