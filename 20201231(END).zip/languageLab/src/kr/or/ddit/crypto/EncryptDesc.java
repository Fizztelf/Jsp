package kr.or.ddit.crypto;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class EncryptDesc {
	public static void main(String[] args) throws Exception {
		String password = "abAB12";
		String encoded = encryptSha512(password);
		System.out.println(encoded);
//		String plain = "대덕인재개발원401호";
//		long start = System.currentTimeMillis();
//		encryptAESExample(plain);
//		long end = System.currentTimeMillis();
//		System.out.printf("AES - 소요시간 %d ms\n", (end-start));
//		start = System.currentTimeMillis();
//		encryptRSAExample(plain);
//		end = System.currentTimeMillis();
//		System.out.printf("RSA - 소요시간 %d ms\n", (end-start));
	}
	
	public static String encryptSha512(String plain) throws NoSuchAlgorithmException {
//		1. 단방향 (해시 함수) : 다양한 입력데이터를 일정 길이의 해시 코드로 생성할 때 사용
		MessageDigest md = MessageDigest.getInstance("SHA-512");
		byte[] encrypted = md.digest(plain.getBytes());
		System.out.println(encrypted.length);
		String encoded = Base64.getEncoder().encodeToString(encrypted);
		System.out.println(encoded);
		return encoded;
	}
	
	public static void encryptAESExample(String plain) throws Exception {
//		String ivString = "아무거나";
//		MessageDigest md5 = MessageDigest.getInstance("MD5");
//		byte[] iv = md5.digest(ivString.getBytes());
		SecureRandom random = new SecureRandom();
		byte[] iv = new byte[128/8];
		random.nextBytes(iv);
		//		2. 양방향-> 대칭키
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");
		keyGen.init(128);
		SecretKey secretKey = keyGen.generateKey();
		IvParameterSpec ivSpec = new IvParameterSpec(iv);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
		byte[] encrypted = cipher.doFinal(plain.getBytes());
		String encoded = Base64.getEncoder().encodeToString(encrypted);
		
		byte[] decoded = Base64.getDecoder().decode(encoded);
		cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
		byte[] decrypted = cipher.doFinal(decoded);
	}
	
	public static void encryptRSAExample(String plain) throws Exception{
		// 3. 양방향 -> 비대칭키(공개키)
		KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
		keyPairGen.initialize(2048);
		KeyPair pair = keyPairGen.generateKeyPair();
		PrivateKey privateKey = pair.getPrivate();
		PublicKey publicKey = pair.getPublic();
		
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, privateKey);
		byte[] encrypted = cipher.doFinal(plain.getBytes());
		String encoded = Base64.getEncoder().encodeToString(encrypted);
//		String encoded = URLEncoder.encode(new String(encrypted) , "UTF-8");
		
//		String decoded = URLDecoder.decode(encoded, "UTF-8");
		byte[] decoded = Base64.getDecoder().decode(encoded);
		
		cipher.init(Cipher.DECRYPT_MODE, publicKey);
		byte[] decrtyped = cipher.doFinal(decoded);
	}
}










