package kr.or.ddit.annotation.test;

public class TestWithOutAnnotation {

}
