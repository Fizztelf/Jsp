package kr.or.ddit.annotation.stereotype;

import static java.lang.annotation.ElementType.*;

import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.*;
import java.lang.annotation.Target;

@Target({TYPE, METHOD})
@Retention(RUNTIME)
public @interface MarkerAnnotation {
	String value();
	int option() default 1;
}

















