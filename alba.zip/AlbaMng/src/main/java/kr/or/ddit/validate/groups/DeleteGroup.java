package kr.or.ddit.validate.groups;

public interface DeleteGroup {

}
