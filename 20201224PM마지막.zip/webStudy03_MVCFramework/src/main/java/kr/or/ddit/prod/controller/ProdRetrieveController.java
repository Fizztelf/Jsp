package kr.or.ddit.prod.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import kr.or.ddit.mvc.annotation.resolvers.ModelAttribute;
import kr.or.ddit.mvc.annotation.resolvers.RequestParam;
import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;
import kr.or.ddit.prod.service.IProdService;
import kr.or.ddit.prod.service.ProdServiceImpl;
import kr.or.ddit.utils.JsonResponseUtils;
import kr.or.ddit.vo.PagingVO;
import kr.or.ddit.vo.ProdVO;

@Controller
public class ProdRetrieveController{
	private static final Logger logger = LoggerFactory.getLogger(ProdRetrieveController.class);
	private IProdService service = ProdServiceImpl.getInstance();
	
	@RequestMapping("/prod/prodList.do")
	public String prodList(
			@RequestParam(value="page", required=false, defaultValue="1") int currentPage,    
			@ModelAttribute("searchDetail") ProdVO searchDetail,
			HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PagingVO<ProdVO> pagingVO = new PagingVO<>(7, 3);
		// 목록 조회와 카운트 조회시 동일 검색 조건 사용.
//		pagingVO.setSearchVO(searchVO);
		pagingVO.setSearchDetail(searchDetail);
		
		int totalRecord = service.retrieveProdCount(pagingVO);
		pagingVO.setTotalRecord(totalRecord);
		pagingVO.setCurrentPage(currentPage);
		
		List<ProdVO> prodList = service.retrieveProdList(pagingVO);
		pagingVO.setDataList(prodList);
		
		req.setAttribute("pagingVO", pagingVO);
		
		String accept = req.getHeader("Accept");
		if(StringUtils.containsIgnoreCase(accept, "json")) {
			JsonResponseUtils.toJsonResponse(req, resp);
			return null;
		}else {
			return "prod/prodList";
			
		}
		
	}
	
	@RequestMapping("/prod/prodView.do")
	public String prodView(@RequestParam("what") String prod_id, HttpServletRequest req){
		ProdVO prod = service.retrieveProd(prod_id);
		req.setAttribute("prod", prod);
		
		return "prod/ajax/prodView";
	}
}




























