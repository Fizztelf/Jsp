package kr.or.ddit.servlet04;

import kr.or.ddit.mvc.stereotype.Controller;
import kr.or.ddit.mvc.stereotype.RequestMapping;

@Controller
public class LoginFormController{
	
	@RequestMapping("/login/loginForm.do")
	public String doGet(){
		return "login/loginForm";
	}
}






















