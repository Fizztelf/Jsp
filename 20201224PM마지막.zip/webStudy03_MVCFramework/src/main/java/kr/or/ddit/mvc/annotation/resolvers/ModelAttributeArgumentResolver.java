package kr.or.ddit.mvc.annotation.resolvers;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Parameter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.ClassUtils;

import kr.or.ddit.vo.MemberVO;

public class ModelAttributeArgumentResolver implements IHandlerMethodArgumentResolver {

	@Override
	public boolean isSupported(Parameter parameter) {
 		boolean supported = parameter.getAnnotation(ModelAttribute.class)!=null;
  		Class<?> parametetType = parameter.getType();
  		supported = supported && 
  					!ClassUtils.isPrimitiveOrWrapper(parametetType) && 
  					!String.class.equals(parametetType);
		return supported;
	}

	@Override
	public Object argumentResolve(Parameter parameter, HttpServletRequest req, HttpServletResponse resp) throws ServletException {
		Class<?> parametetType = parameter.getType();
		try {
			Object vo = parametetType.newInstance();
	 		ModelAttribute modelAttribute = parameter.getAnnotation(ModelAttribute.class);
	  		String attrName = modelAttribute.value();
			req.setAttribute(attrName, vo);
			
			Map<String, String[]> parameterMap = req.getParameterMap();
			BeanUtils.populate(vo, parameterMap);
			return vo;
		} catch (Exception e) {
			throw new ServletException(e);
		}
		
	}

}













